package com.app.properti.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.LinearLayout.LayoutParams;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.ActivityOptionsCompat;
import androidx.core.view.ViewCompat;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.app.properti.AppConfig;
import com.app.properti.R;
import com.app.properti.adapter.AdapterImageHoriz;
import com.app.properti.advertise.AdNetworkHelper;
import com.app.properti.data.ThisApp;
import com.app.properti.databinding.ActivityListingDetailsBinding;
import com.app.properti.databinding.ItemFacilityBinding;
import com.app.properti.model.Facility;
import com.app.properti.model.Post;
import com.app.properti.room.table.EntityListing;
import com.app.properti.utils.Tools;
import com.google.android.material.snackbar.Snackbar;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.ArrayList;
import java.util.List;

import dreamspace.blogger.sdk.listener.RequestListener;
import dreamspace.blogger.sdk.model.ParamList;
import dreamspace.blogger.sdk.model.RespPosts;

public class ActivityListingDetail extends AppCompatActivity {

    private static final String EXTRA_OBJ = "key.EXTRA_OBJ";

    // give preparation animation activity transition
    public static void navigate(AppCompatActivity activity, View sharedView, Post p) {
        Intent intent = new Intent(activity, ActivityListingDetail.class);
        intent.putExtra(EXTRA_OBJ, p);
        ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation(activity, sharedView, EXTRA_OBJ);
        ActivityCompat.startActivity(activity, intent, options.toBundle());
    }

    public static void navigate(Activity activity, Post object) {
        Intent i = new Intent(activity, ActivityListingDetail.class);
        i.putExtra(EXTRA_OBJ, object);
        activity.startActivity(i);
    }

    private ActivityListingDetailsBinding binding;
    private ProgressDialog progressDialog;
    private Post post;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityListingDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // animation transition
        ViewCompat.setTransitionName(binding.image, EXTRA_OBJ);

        post = (Post) getIntent().getSerializableExtra(EXTRA_OBJ);

        initToolbar();
        initComponent();
        checkFavorite();
        prepareAds();

        if (post.isDraft()) {
            loadPostDetails();
        }
        Tools.RTLMode(getWindow());
    }

    private void initToolbar() {
        Tools.setMarginStatusBarToolbar(this, binding.toolbar);
        binding.toolbarMenuClose.setOnClickListener(v -> finish());

    }

    private void initComponent() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage(getString(R.string.please_wait));
        if (post.isDraft()) {
            binding.lytContent.setVisibility(View.INVISIBLE);
            return;
        }

        binding.lytContent.setVisibility(View.VISIBLE);
        binding.image.setOnClickListener(view -> {
            ActivityFullScreenImage.navigate(this, new ArrayList<>(post.images), 0, view);
        });
        binding.toolbarMenuSaved.setOnClickListener(view -> {
            toggleFavorite();
        });
        binding.toolbarMenuShare.setOnClickListener(v -> Tools.methodShare(this, post.link));

        Tools.displayImage(this, binding.image, post.image);
        binding.title.setText(post.title);

        binding.price.setVisibility(TextUtils.isEmpty(post.price) ? View.GONE : View.VISIBLE);
        binding.price.setText(TextUtils.isEmpty(post.price) ? "" : post.price);

        binding.address.setVisibility(TextUtils.isEmpty(post.address) ? View.GONE : View.VISIBLE);
        binding.address.setText(TextUtils.isEmpty(post.address) ? "" : post.address);

        binding.btContact.setOnClickListener(v -> {
            Tools.actionContact(this, post.title, post.contact);
        });

        if (post.category != null && post.category.size() > 0) {
            String categories = String.join(", ", post.category);
            binding.category.setText(categories);
        } else {
            binding.category.setVisibility(View.GONE);
        }

        int gallerySize = AppConfig.general.image_details_gallery;
        binding.galleryRecycler.setLayoutManager(new LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false));
        binding.galleryRecycler.post(() -> {
            int margin = (int) getResources().getDimension(R.dimen.spacing_22) * (gallerySize - 1);
            int itemSize = (binding.galleryRecycler.getWidth() - margin) / gallerySize;
            AdapterImageHoriz adapter = new AdapterImageHoriz(ActivityListingDetail.this, itemSize, post.images);
            binding.galleryRecycler.setAdapter(adapter);
            adapter.setOnItemClickListener((view, s, pos) -> {
                Tools.displayImage(ActivityListingDetail.this, binding.image, post.images.get(pos));
            });
        });

        Document htmlData = Jsoup.parse(post.content);
        if (AppConfig.general.hide_all_image_from_listing_description) {
            for (Element element : htmlData.select("img")) {
                assert element != null;
                Element parent_element = element.parent();
                assert parent_element != null;
                if (parent_element.tagName().equals("a")) {
                    parent_element.remove();
                } else {
                    if (element.hasAttr("src")) {
                        element.remove();
                    }
                }
            }
        }

        Tools.cleanBeginningWhiteSpace(htmlData);
        String content = htmlData.html();

        Tools.displayContentHtml(this, binding.content, content);

        // populate facilities
        displayFacilities();
    }

    private void displayFacilities() {
        List<Facility> facilities = new ArrayList<>();
        if (!TextUtils.isEmpty(post.bath_room)) {
            facilities.add(new Facility(R.drawable.ic_bathtub, post.bath_room + " " + getString(R.string.bath_room)));
        }
        if (!TextUtils.isEmpty(post.bed_room)) {
            facilities.add(new Facility(R.drawable.ic_bed, post.bed_room + " " + getString(R.string.bed_room)));
        }
        if (!TextUtils.isEmpty(post.cars)) {
            facilities.add(new Facility(R.drawable.ic_car, post.cars + " " + getString(R.string.car_parking)));
        }
        if (!TextUtils.isEmpty(post.area_size)) {
            facilities.add(new Facility(R.drawable.ic_aspect_ratio, post.area_size));
        }
        if (!TextUtils.isEmpty(post.kitchen_room)) {
            facilities.add(new Facility(R.drawable.ic_kitchen, post.kitchen_room + " " + getString(R.string.kitchen_room)));
        }

        if (facilities.isEmpty()) {
            binding.lytFacilities.setVisibility(View.GONE);
            return;
        }
        binding.flexFacilities.removeAllViews();
        binding.flexFacilities.post(() -> {
            int widthFacilities = binding.flexFacilities.getWidth() / 2;
            for (Facility fac : facilities) {
                ItemFacilityBinding viewItem = ItemFacilityBinding.inflate(LayoutInflater.from(ActivityListingDetail.this));
                viewItem.icon.setImageResource(fac.icon);
                viewItem.title.setText(fac.title);
                LayoutParams params = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT);
                params.width = widthFacilities;
                viewItem.lytParent.setLayoutParams(params);
                viewItem.lytParent.requestLayout();
                binding.flexFacilities.addView(viewItem.getRoot());
            }
        });
    }

    private void toggleFavorite() {
        if (ThisApp.dao().getListing(post.id) != null) {
            ThisApp.dao().deleteListing(post.id);
            Snackbar.make(binding.getRoot(), R.string.remove_from_favorite, Snackbar.LENGTH_SHORT).show();
        } else {
            ThisApp.dao().insertListing(EntityListing.entity(post));
            Snackbar.make(binding.getRoot(), R.string.add_to_favorite, Snackbar.LENGTH_SHORT).show();
        }
        checkFavorite();
    }

    private void checkFavorite() {
        if (ThisApp.dao().getListing(post.id) == null) {
            binding.toolbarMenuSaved.setImageResource(R.drawable.ic_bookmark_border);
        } else {
            binding.toolbarMenuSaved.setImageResource(R.drawable.ic_bookmark);
        }
    }

    private void prepareAds() {
        AdNetworkHelper adNetworkHelper = new AdNetworkHelper(this);
        adNetworkHelper.updateConsentStatus();
        adNetworkHelper.loadBannerAd(AppConfig.ads.ad_listing_details_banner);
    }

    private void loadPostDetails() {
        progressDialog.show();

        ParamList param = new ParamList();
        param.url = AppConfig.general.blogger_url;
        param.page = "1";
        param.count = "1";
        param.keyword = post.id;

        ThisApp.get().bloggerAPI.getPosts(param, new RequestListener<RespPosts>() {
            @Override
            public void onSuccess(RespPosts resp) {
                super.onSuccess(resp);
                progressDialog.hide();
                if (resp.list == null || resp.list.size() == 0) {
                    requestFailedDialog(getString(R.string.failed_not_found));
                } else {
                    post = Tools.parseListingToPost(resp.list.get(0));
                    initComponent();
                    ThisApp.get().setNotification(null);
                }
            }

            @Override
            public void onFailed(String messages) {
                super.onFailed(messages);
                progressDialog.hide();
                requestFailedDialog(null);
                if (messages != null) Log.e("Error", messages);
            }
        });
    }

    public void requestFailedDialog(String msg) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle(R.string.failed);
        String message = getString(R.string.failed_when_load);
        if (!TextUtils.isEmpty(msg)) message = msg;
        builder.setMessage(message);
        builder.setPositiveButton(R.string.RETRY, (di, i) -> {
            di.dismiss();
            loadPostDetails();
        });
        builder.show();
    }
}