package com.app.properti.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.app.properti.databinding.ItemSliderBinding;
import com.app.properti.model.Page;
import com.app.properti.utils.Tools;

import java.util.ArrayList;
import java.util.List;

public class AdapterImageSlider extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private Context context;
    private List<Page> items = new ArrayList<>();

    public OnItemClickListener onItemClickListener;

    public AdapterImageSlider(Context context) {
        this.context = context;
    }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {
        ItemSliderBinding binding;

        public OriginalViewHolder(@NonNull ItemSliderBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;
        ItemSliderBinding v = ItemSliderBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        vh = new OriginalViewHolder(v);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int pos) {
        int position = holder.getAdapterPosition();
        Page obj = items.get(position);
        if (holder instanceof OriginalViewHolder) {
            OriginalViewHolder v = (OriginalViewHolder) holder;
            final Page page = obj;
            Tools.displayImage(context, v.binding.image, page.image);
            v.binding.lytParent.setOnClickListener(v1 -> {
                if (onItemClickListener != null) {
                    onItemClickListener.onItemClick(v1, page);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return this.items.size();
    }


    public interface OnItemClickListener {
        void onItemClick(View view, Page obj);
    }

    public void setOnItemClickListener(OnItemClickListener onItemClickListener) {
        this.onItemClickListener = onItemClickListener;
    }

    public void setItems(List<Page> items) {
        this.items = new ArrayList<>(items);
        setLastEnd();
        notifyDataSetChanged();
    }

    private void setLastEnd() {
        if (this.items.size() > 0) {
            this.items.add(0, this.items.get(this.items.size() - 1));
            this.items.add(this.items.get(1));
        }
    }
}