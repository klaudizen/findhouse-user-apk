package com.app.properti.model;

public class CategoryHome {

    public String title;
    public int icon;
    public String category;

    public CategoryHome(String title, int icon, String category) {
        this.title = title;
        this.icon = icon;
        this.category = category;
    }

    public CategoryHome() {
    }
}
