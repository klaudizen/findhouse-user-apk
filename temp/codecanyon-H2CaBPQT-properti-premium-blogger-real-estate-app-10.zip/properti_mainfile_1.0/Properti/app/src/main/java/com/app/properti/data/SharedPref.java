package com.app.properti.data;

import android.content.Context;
import android.content.SharedPreferences;

public class SharedPref {

    private static SharedPref mInstance;

    public static synchronized SharedPref get() {
        return mInstance;
    }

    private SharedPreferences sharedPreferences;

    public SharedPref(Context context) {
        mInstance = this;
        sharedPreferences = context.getSharedPreferences("MAIN_PREF", Context.MODE_PRIVATE);
    }

    // Preference for theme
    public void setDarkTheme(boolean flag) {
        sharedPreferences.edit().putBoolean("DARK_THEME", flag).apply();
    }

    public boolean isDarkTheme() {
        return sharedPreferences.getBoolean("DARK_THEME", false);
    }

}
