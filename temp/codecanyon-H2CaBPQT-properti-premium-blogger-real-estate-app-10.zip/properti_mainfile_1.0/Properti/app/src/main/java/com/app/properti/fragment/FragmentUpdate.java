package com.app.properti.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;

import com.app.properti.AppConfig;
import com.app.properti.R;
import com.app.properti.activity.ActivityMain;
import com.app.properti.activity.ActivityUpdateDetails;
import com.app.properti.adapter.AdapterListener;
import com.app.properti.adapter.AdapterUpdate;
import com.app.properti.data.ThisApp;
import com.app.properti.databinding.FragmentUpdateBinding;
import com.app.properti.model.Page;
import com.app.properti.utils.Tools;

import java.util.ArrayList;
import java.util.List;

import dreamspace.blogger.sdk.listener.RequestListener;
import dreamspace.blogger.sdk.model.Listing;
import dreamspace.blogger.sdk.model.ParamList;
import dreamspace.blogger.sdk.model.RespPosts;

public class FragmentUpdate extends Fragment {

    private FragmentUpdateBinding binding;
    private AdapterUpdate adapter;
    private boolean allLoaded = false;

    public static FragmentUpdate instance() {
        return new FragmentUpdate();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentUpdateBinding.inflate(inflater, container, false);
        initComponent();

        requestAction(1);
        return binding.getRoot();
    }

    private void initComponent() {
        binding.recyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 1));

        //set data and list adapter
        adapter = new AdapterUpdate(getActivity(), binding.recyclerView, AppConfig.general.listing_pagination_count);
        binding.recyclerView.setAdapter(adapter);

        // detect when scroll reach bottom
        adapter.setListener(new AdapterListener<Page>() {
            @Override
            public void onClick(View view, String type, Page obj, int position) {
                super.onClick(view, type, obj, position);
                ActivityUpdateDetails.navigate(getActivity(), obj);
                try {
                    ((ActivityMain) getActivity()).showInterstitialAd();
                } catch (Exception e) {
                }
            }

            @Override
            public void onLoadMore(int page) {
                super.onLoadMore(page);
                if (allLoaded) {
                    adapter.setLoaded();
                } else {
                    int next_page = page + 1;
                    requestAction(next_page);
                }
            }
        });

        binding.swipeRefresh.setOnRefreshListener(() -> {
            allLoaded = false;
            adapter.resetListData();
            requestAction(1);
        });
    }

    private void requestAction(final int page_no) {
        if (page_no == 1) {
            showNoItemView(false);
            swipeProgress(true);
        } else {
            adapter.setLoadingOrFailed(null);
        }
        new Handler(Looper.getMainLooper()).postDelayed(() -> request(page_no), 200);
    }

    private void request(Integer pageNo) {
        ParamList param = new ParamList();
        param.url = AppConfig.general.blogger_url;
        param.page = pageNo.toString();
        param.count = AppConfig.general.listing_pagination_count.toString();

        ThisApp.get().bloggerAPI.getPages(param, new RequestListener<RespPosts>() {
            @Override
            public void onSuccess(RespPosts resp) {
                super.onSuccess(resp);
                allLoaded = resp.list.size() < AppConfig.general.listing_pagination_count || resp.list.size() == 0;
                displayApiResult(resp.list);
            }

            @Override
            public void onFailed(String messages) {
                super.onFailed(messages);
                if (messages != null) Log.e("Error", messages);
                onFailRequest();
            }
        });
    }

    private void onFailRequest() {
        swipeProgress(false);
        if (Tools.isConnect(getActivity())) {
            adapter.setLoadingOrFailed(getString(R.string.failed_text));
        } else {
            adapter.setLoadingOrFailed(getString(R.string.no_internet_text));
        }
    }

    private void showNoItemView(boolean show) {
        ((TextView) binding.lytFailed.findViewById(R.id.failed_subtitle)).setText(getString(R.string.empty_state_no_data));
        if (show) {
            binding.lytFailed.setVisibility(View.VISIBLE);
        } else {
            binding.lytFailed.setVisibility(View.GONE);
        }
    }

    private void swipeProgress(final boolean show) {
        binding.swipeRefresh.post(() -> binding.swipeRefresh.setRefreshing(show));
        if (!show) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.shimmer.setVisibility(View.GONE);
            binding.shimmer.stopShimmer();
            return;
        }
        binding.recyclerView.setVisibility(View.GONE);
        binding.shimmer.setVisibility(View.VISIBLE);
        binding.shimmer.startShimmer();
    }

    private void displayApiResult(final List<Listing> items) {
        List<Page> places = new ArrayList<>();
        for (Listing l : items) {
            places.add(Tools.parseListingToPage(l));
        }
        adapter.insertData(places);
        swipeProgress(false);
        showNoItemView(adapter.getItemCount() == 0);
    }

    @Override
    public void onPause() {
        super.onPause();
    }

    @Override
    public void onResume() {
        super.onResume();
    }
}