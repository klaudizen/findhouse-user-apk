package com.app.properti.activity;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.app.properti.AppConfig;
import com.app.properti.R;
import com.app.properti.advertise.AdNetworkHelper;
import com.app.properti.data.ThisApp;
import com.app.properti.databinding.ActivityUpdateDetailsBinding;
import com.app.properti.model.Page;
import com.app.properti.utils.Tools;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.util.ArrayList;

import dreamspace.blogger.sdk.listener.RequestListener;
import dreamspace.blogger.sdk.model.Listing;
import dreamspace.blogger.sdk.model.ParamList;
import dreamspace.blogger.sdk.model.RespPosts;

public class ActivityUpdateDetails extends AppCompatActivity {

    private static final String EXTRA_OBJECT = "key.EXTRA_OBJECT";

    public static void navigate(Activity activity, Page obj) {
        Intent i = new Intent(activity, ActivityUpdateDetails.class);
        i.putExtra(EXTRA_OBJECT, obj);
        activity.startActivity(i);
    }

    private ActivityUpdateDetailsBinding binding;
    private Page page;
    private ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityUpdateDetailsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        page = (Page) getIntent().getSerializableExtra(EXTRA_OBJECT);
        initComponent();
        initToolbar();
        prepareAds();
        if (page.isDraft()) {
            loadPageDetails(1);
        }
        Tools.RTLMode(getWindow());
    }

    private void initToolbar() {
        Tools.setMarginStatusBarToolbar(this, binding.toolbar);
        binding.image.setOnClickListener(view -> {
            ActivityFullScreenImage.navigate(this, page.image);
        });

        binding.toolbarMenuClose.setOnClickListener(v -> finish());
        binding.toolbarMenuShare.setOnClickListener(v -> Tools.methodShare(this, page.link));
    }

    private void initComponent() {
        progressDialog = new ProgressDialog(this);
        progressDialog.setCancelable(false);
        progressDialog.setMessage(getString(R.string.please_wait));
        if (page.isDraft()) {
            binding.lytContent.setVisibility(View.INVISIBLE);
            return;
        }

        binding.lytContent.setVisibility(View.VISIBLE);
        binding.title.setText(page.title);
        binding.date.setText(Tools.getDateTime(page.published, false));

        Document htmlData = Jsoup.parse(page.content);
        if (AppConfig.general.hide_all_image_from_update_description) {
            for (Element element : htmlData.select("img")) {
                assert element != null;
                Element parent_element = element.parent();
                assert parent_element != null;
                if (parent_element.tagName().equals("a")) {
                    parent_element.remove();
                } else {
                    if (element.hasAttr("src")) {
                        element.remove();
                    }
                }
            }
        }

        Tools.cleanBeginningWhiteSpace(htmlData);
        String content = htmlData.html();

        Tools.displayContentHtml(this, binding.content, content);
        if (!TextUtils.isEmpty(page.image)) {
            Tools.displayImage(this, binding.image, page.image);

            ArrayList<String> images = new ArrayList<>();
            images.add(page.image);
            binding.image.setOnClickListener(v -> ActivityFullScreenImage.navigate(this, images, 0, v));
        }
    }

    private void loadPageDetails(Integer pageIndex) {
        progressDialog.show();

        Integer count = 10;
        ParamList param = new ParamList();
        param.url = AppConfig.general.blogger_url;
        param.page = pageIndex.toString();
        param.count = count.toString();

        ThisApp.get().bloggerAPI.getPages(param, new RequestListener<RespPosts>() {
            @Override
            public void onSuccess(RespPosts resp) {
                super.onSuccess(resp);
                progressDialog.hide();
                if (resp == null) {
                    requestFailedDialog(null, pageIndex);
                } else if (resp.list != null) {
                    for (Listing l : resp.list) {
                        if (l.link.equals(page.id)) { // found
                            page = Tools.parseListingToPage(l);
                            break;
                        }
                    }
                    if (!page.isDraft()) {
                        initComponent();
                        ThisApp.get().setNotification(null);
                    } else if (resp.list.size() == count) {
                        loadPageDetails(pageIndex + 1);
                    } else {
                        requestFailedDialog(getString(R.string.failed_not_found), pageIndex);
                    }
                }
            }

            @Override
            public void onFailed(String messages) {
                super.onFailed(messages);
                progressDialog.hide();
                requestFailedDialog(null, pageIndex);
                if (messages != null) Log.e("Error", messages);
            }
        });
    }

    public void requestFailedDialog(String msg, int pageIndex) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setTitle(R.string.failed);
        String message = getString(R.string.failed_when_load);
        if (!TextUtils.isEmpty(msg)) message = msg;
        builder.setMessage(message);
        builder.setPositiveButton(R.string.RETRY, (di, i) -> {
            di.dismiss();
            loadPageDetails(pageIndex);
        });
        builder.show();
    }

    private void prepareAds() {
        AdNetworkHelper adNetworkHelper = new AdNetworkHelper(this);
        adNetworkHelper.updateConsentStatus();
        adNetworkHelper.loadBannerAd(AppConfig.ads.ad_update_details_banner);
    }

}