package com.app.properti.model;

import android.text.TextUtils;

import java.io.Serializable;
import java.util.List;

public class Post implements Serializable {

    public String id;
    public String type;
    public String title;

    public String price;
    public String address;
    public String contact;
    public String bed_room;
    public String bath_room;
    public String kitchen_room;
    public String cars;
    public String area_size;

    public String content;
    public String link;
    public String image;
    public List<String> category;
    public List<String> images;
    public String published;
    public String updated;

    public Post() {
    }

    public boolean isDraft() {
        return TextUtils.isEmpty(title);
    }
}
