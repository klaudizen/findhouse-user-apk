package com.app.properti.model;

import java.util.List;

public class SectionSlider {

    public List<Page> pages;

    public SectionSlider(List<Page> pages) {
        this.pages = pages;
    }
}
