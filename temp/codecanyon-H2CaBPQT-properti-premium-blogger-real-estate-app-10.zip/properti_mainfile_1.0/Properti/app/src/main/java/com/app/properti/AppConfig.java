package com.app.properti;

import com.app.properti.model.CategoryHome;
import com.app.properti.utils.AppConfigExt;

import java.io.Serializable;

import dreamspace.ads.sdk.data.AdNetworkType;

public class AppConfig extends AppConfigExt implements Serializable {

    /* -------------------------------------- INSTRUCTION : ----------------------------------------
     * This is config file used for this app, you can configure Ads, Notification, and General data from this file
     * some values are not explained and can be understood easily according to the variable name
     * value can change remotely (optional), please read documentation to follow instruction
     *
     * variable with UPPERCASE name will NOT fetch / replace with remote config
     * variable with LOWERCASE name will fetch / replace with remote config
     * See video Remote Config tutorial https://www.youtube.com/watch?v=tOKXwOTqOzA
     ----------------------------------------------------------------------------------------------*/

    /* set true for fetch config with firebase remote config, */
    public static final boolean USE_REMOTE_CONFIG = false;

    /* force rtl layout direction */
    public static final boolean RTL_LAYOUT = false;

    /* covert logo at splash and home toolbar into one color */
    public static final boolean TINT_LOGO = true;

    /* home category with icon, format is (Title, Res Icon, Blogger Label)
     * Title and Blogger Label may different */
    public static CategoryHome[] HOME_CATEGORY = {
            new CategoryHome("Houses", R.drawable.ic_category_house, "Houses"),
            new CategoryHome("Apartments", R.drawable.ic_category_apartment, "Apartments"),
            new CategoryHome("Villas", R.drawable.ic_category_villa, "Villas"),
            new CategoryHome("Offices", R.drawable.ic_category_office, "Offices")
    };

    /* config for General Application */
    public static class General {

        /* Edit Blogger with yours. Make sure its not using http and doesn't have backslash('/') in the end url. */
        /* ex https://properti-app.blogspot.com/ to properti-app.blogspot.com */
        public String blogger_url = "properti-app.blogspot.com";

        /* access key generated from : https://dream-space.web.id/blogger/access-key  */
        public String access_key = "QjbwT4oKsUzSYo4pOr/7G64t6IaPQVakQ4I1laAhTn2UI6isQGE2A4vgVHwVOPhc:ZmVkY2JhOTg3NjU0MzIxMA==";

        /* if contact from specific listing empty this contact will use */
        public String contact_agent = "https://wa.me/6285171505082";

        /* maximum slider show in home */
        /* home slider data come from blogger PAGE */
        public Integer limit_home_slider = 3;

        /* count first image showing on listing details page */
        public Integer image_details_gallery = 4;

        /* contact agent message prefix */
        public String contact_message_prefix = "Hi, I am interesting with";

        /* fill this values when you publish app not in google play */
        public String non_playstore_market_android = "";

        /* true for open link in internal app browser, not external app browser */
        public boolean open_link_in_app = true;

        /* amount data each api request listing, used when load listing from server */
        public Integer listing_pagination_count = 10;

        /* true for open link in external browser, no inside app */
        public boolean enable_text_selection = false;

        /* sort category alphabetically */
        public boolean sort_category_alphabetically = true;

        /* hide image from description, LISTING and UPDATE */
        public boolean hide_all_image_from_listing_description = true;
        public boolean hide_all_image_from_update_description = true;

        /* 3 links below will use on setting page */
        public String privacy_policy_url = "https://dream-space.web.id/privacy-policy";
        public String more_apps_url = "https://codecanyon.net/user/dream_space/portfolio?order_by=sales";
        public String contact_us_url = "https://dream-space.web.id/";
    }

    /* config for Ad Network */
    public static class Ads {

        /* enable disable ads */
        public boolean ad_enable = true;

        /* SINGLE Ad network selection,
         * this value ignored if you fill array ad_networks below
         * Available ad networks ADMOB, FAN, UNITY, IRON SOURCE, APPLOVIN */
        public AdNetworkType ad_network = AdNetworkType.ADMOB;

        /* MULTI Ad network selection,
         * Fill this array to enable ad backup flow, left this empty to use single ad_network above
         * app will try show sequentially from this array
         * example flow IRONSOURCE > ADMOB > UNITY */
        public AdNetworkType[] ad_networks = {
                AdNetworkType.IRONSOURCE,
                AdNetworkType.ADMOB,
                AdNetworkType.UNITY,
        };

        /* ad backup flow retry attempt each network */
        public int retry_every_ad_networks = 2;

        /* ad backup flow stat from beginning when all failed */
        public boolean retry_from_start = false;

        /* ad backup flow retry attempt cycle */
        public int retry_from_start_max = 2;

        public boolean ad_enable_gdpr = true;

        /* show interstitial after several action, this value for action counter */
        public int ad_inters_interval = 5;

        /* disable enable ads each page */
        public boolean ad_main_banner = true;
        public boolean ad_main_interstitial = true;
        public boolean ad_listing_details_banner = true;
        public boolean ad_update_details_banner = true;
        public boolean ad_category_banner = true;
        public boolean ad_search_banner = true;

        /* ad unit for ADMOB */
        public String ad_admob_publisher_id = "pub-3940256099942544";
        public String ad_admob_banner_unit_id = "ca-app-pub-3940256099942544/6300978111";
        public String ad_admob_interstitial_unit_id = "ca-app-pub-3940256099942544/1033173712";

        /* ad unit for FAN */
        public String ad_fan_banner_unit_id = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";
        public String ad_fan_interstitial_unit_id = "IMG_16_9_APP_INSTALL#YOUR_PLACEMENT_ID";

        /* ad unit for IRON SOURCE */
        public String ad_ironsource_app_key = "1a8bcf05d";
        public String ad_ironsource_banner_unit_id = "DefaultBanner";
        public String ad_ironsource_interstitial_unit_id = "DefaultInterstitial";

        /* ad unit for UNITY */
        public String ad_unity_game_id = "4297717";
        public String ad_unity_banner_unit_id = "Banner_Android";
        public String ad_unity_interstitial_unit_id = "Interstitial_Android";

        /* ad unit for APPLOVIN */
        public String ad_applovin_banner_unit_id = "d62dc7470d3f119b";
        public String ad_applovin_interstitial_unit_id = "4e1b0167531b4dd8";
    }

    /* One Signal Notification */
    public static class Notification {
        public String notif_one_signal_appid = "3febbd8c-7716-4c4f-95a5-48e868714a79";
    }

}
