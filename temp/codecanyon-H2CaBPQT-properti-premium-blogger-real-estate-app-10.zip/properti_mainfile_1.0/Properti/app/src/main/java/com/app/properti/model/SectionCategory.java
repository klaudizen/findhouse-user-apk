package com.app.properti.model;

import java.util.Arrays;
import java.util.List;

public class SectionCategory {

    public List<CategoryHome> categories;

    public SectionCategory(List<CategoryHome> categories) {
        this.categories = categories;
    }

    public SectionCategory(CategoryHome[] categories) {
        this.categories = Arrays.asList(categories);
    }
}
