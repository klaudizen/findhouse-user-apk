package com.app.properti.data;

import android.app.Application;
import android.location.Location;

import com.app.properti.AppConfig;
import com.app.properti.BuildConfig;
import com.app.properti.advertise.AdNetworkHelper;
import com.app.properti.model.Post;
import com.app.properti.notification.NotificationHelper;
import com.app.properti.room.AppDatabase;
import com.app.properti.room.DAO;
import com.app.properti.room.table.NotificationEntity;
import com.app.properti.utils.Tools;
import com.google.firebase.FirebaseApp;
import com.google.firebase.analytics.FirebaseAnalytics;
import com.google.firebase.remoteconfig.FirebaseRemoteConfig;
import com.google.firebase.remoteconfig.FirebaseRemoteConfigSettings;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dreamspace.blogger.sdk.BloggerAPI;

public class ThisApp extends Application {

    private static ThisApp mInstance;
    private static SharedPref sharedPref;
    private static DAO dao;

    public static synchronized SharedPref pref() {
        return sharedPref;
    }

    public static synchronized DAO dao() {
        return dao;
    }

    public static synchronized ThisApp get() {
        return mInstance;
    }

    private Location location = null;
    private List<String> categories = new ArrayList<>();

    private NotificationEntity notification;
    private FirebaseRemoteConfig firebaseRemoteConfig;

    public BloggerAPI bloggerAPI;


    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        sharedPref = new SharedPref(this);
        dao = AppDatabase.getDb(this).get();

        initFirebase();
        initRemoteConfig();

        Tools.applyTheme(ThisApp.pref().isDarkTheme());

        // Init Firebase Notification and One Signal
        NotificationHelper.init(this);
    }

    private void initRemoteConfig() {
        firebaseRemoteConfig = FirebaseRemoteConfig.getInstance();
        if (!AppConfig.USE_REMOTE_CONFIG) return;
        FirebaseRemoteConfigSettings configSettings = new FirebaseRemoteConfigSettings.Builder()
                .setMinimumFetchIntervalInSeconds(BuildConfig.DEBUG ? 0 : 60)
                .setFetchTimeoutInSeconds(4)
                .build();
        firebaseRemoteConfig.setConfigSettingsAsync(configSettings);
    }

    private void initFirebase() {
        // Obtain the Firebase Analytics.
        FirebaseApp.initializeApp(this);
        FirebaseAnalytics.getInstance(this);
    }

    public void initBloggerAPI() {
        bloggerAPI = new BloggerAPI(AppConfig.general.access_key);
    }


    public FirebaseRemoteConfig getFirebaseRemoteConfig() {
        return firebaseRemoteConfig;
    }

    public NotificationEntity getNotification() {
        return notification;
    }

    public void setNotification(NotificationEntity notification) {
        this.notification = notification;
    }

    public List<String> getCategories() {
        return categories;
    }

    public void setCategories(List<String> categories) {
        if (AppConfig.general.sort_category_alphabetically) Collections.sort(categories);
        this.categories = categories;
    }
}
