package com.app.properti.utils;

import static com.bumptech.glide.load.resource.drawable.DrawableTransitionOptions.withCrossFade;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentSender;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.text.Html;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.URLUtil;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.ColorInt;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.browser.customtabs.CustomTabColorSchemeParams;
import androidx.browser.customtabs.CustomTabsIntent;
import androidx.core.app.ShareCompat;
import androidx.core.content.res.ResourcesCompat;

import com.app.properti.AppConfig;
import com.app.properti.BuildConfig;
import com.app.properti.R;
import com.app.properti.activity.ActivityFullScreenImage;
import com.app.properti.activity.ActivityListingDetail;
import com.app.properti.activity.ActivitySplash;
import com.app.properti.activity.ActivityUpdateDetails;
import com.app.properti.activity.ActivityWebView;
import com.app.properti.data.SharedPref;
import com.app.properti.data.ThisApp;
import com.app.properti.model.Page;
import com.app.properti.model.Post;
import com.app.properti.room.table.NotificationEntity;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.CollapsingToolbarLayout;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.play.core.appupdate.AppUpdateInfo;
import com.google.android.play.core.appupdate.AppUpdateManager;
import com.google.android.play.core.appupdate.AppUpdateManagerFactory;
import com.google.android.play.core.install.InstallStateUpdatedListener;
import com.google.android.play.core.install.model.AppUpdateType;
import com.google.android.play.core.install.model.InstallStatus;
import com.google.android.play.core.install.model.UpdateAvailability;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.nodes.Node;
import org.jsoup.select.Elements;
import org.jsoup.select.NodeVisitor;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

import dreamspace.blogger.sdk.model.Listing;

public class Tools {

    public static void RTLMode(Window window) {
        if (AppConfig.RTL_LAYOUT) {
            window.getDecorView().setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        }
    }


    public static void setMarginStatusBarToolbar(Context context, Toolbar toolbar) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.LOLLIPOP) return;
        CollapsingToolbarLayout.LayoutParams lp = (CollapsingToolbarLayout.LayoutParams) toolbar.getLayoutParams();
        lp.setMargins(lp.leftMargin, lp.topMargin + getStatusBarHeight(context), lp.rightMargin, lp.bottomMargin);
        toolbar.setLayoutParams(lp);
    }

    public static void darkNavigation(Activity activity) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            activity.getWindow().setNavigationBarColor(Color.BLACK);
            activity.getWindow().setStatusBarColor(Color.BLACK);
            activity.getWindow().getDecorView().setSystemUiVisibility(0);
        }
    }

    public static void restartApp(Activity activity) {
        activity.finishAffinity();
        activity.startActivity(new Intent(activity, ActivitySplash.class));
    }

    public static Post parseListingToPost(Listing listing) {
        Post p = new Post();
        p.id = listing.id;
        p.type = listing.type;
        p.title = listing.title;
        p.published = listing.published;
        p.updated = listing.updated;
        p.content = listing.content;
        p.link = listing.link;
        p.image = null;
        p.images = new ArrayList<>();
        if (!TextUtils.isEmpty(p.content)) {
            Document htmlData = Jsoup.parse(listing.content);

            p.images = findImagesFromContent(htmlData);
            p.price = findDataFromContent(htmlData, "app_price");
            p.address = findDataFromContent(htmlData, "app_address");
            p.contact = findDataFromContent(htmlData, "app_contact");

            p.bed_room = findDataFromContent(htmlData, "app_bed_room");
            p.bath_room = findDataFromContent(htmlData, "app_bath_room");
            p.kitchen_room = findDataFromContent(htmlData, "app_kitchen_room");
            p.cars = findDataFromContent(htmlData, "app_cars");
            p.area_size = findDataFromContent(htmlData, "app_area_size");

            if (p.images != null && p.images.size() > 0) {
                p.image = p.images.get(0);
            }
        }

        p.category = listing.category;
        return p;
    }


    public static Page parseListingToPage(Listing listing) {

        Page n = new Page();
        n.id = listing.id;
        n.type = listing.type;
        n.title = listing.title;
        n.published = listing.published;
        n.updated = listing.updated;
        n.content = listing.content;
        n.link = listing.link;
        n.image = null;

        if (!TextUtils.isEmpty(n.content)) {
            Document htmlData = Jsoup.parse(listing.content);
            Element e = htmlData.select("img").first();
            if (e != null && e.hasAttr("src")) {
                n.image = e.attr("src");
            }
            n.brief = getBrief(htmlData.text());
        }

        return n;
    }

    public static String getBrief(String htmlData) {
        if (htmlData != null && !htmlData.trim().equals("")) {
            String s = htmlData.replace("", "");
            if (s.length() > 200) {
                return s.substring(0, 200);
            }
            return s;
        } else {
            return "";
        }
    }

    public static List<String> findImagesFromContent(Document htmlData) {
        List<String> images = new ArrayList<>();
        Elements elements = htmlData.select("img");
        for (Element e : elements) {
            if (e.hasAttr("src")) {
                images.add(e.attr("src"));
            }
        }

        return images;
    }

    public static String findDataFromContent(Document htmlData, String id) {
        Element element = htmlData.getElementById(id);
        if (element != null) {
            return element.text();
        }
        return null;
    }

    public static void fullScreen(Activity activity) {
        Window w = activity.getWindow();
        w.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
    }

    public static void displayImage(Context ctx, ImageView img, String url) {
        if (TextUtils.isEmpty(url)) return;
        try {
            Glide.with(ctx.getApplicationContext()).load(url)
                    .transition(withCrossFade())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .into(img);
        } catch (Exception e) {
            Log.e("tag", "error img => " + e.getMessage());
        }
    }

    public static void displayImageThumb(Context ctx, ImageView img, String url, float thumb) {
        if (TextUtils.isEmpty(url)) return;
        try {
            Glide.with(ctx.getApplicationContext()).load(url)
                    .transition(withCrossFade())
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .thumbnail(thumb)
                    .into(img);
        } catch (Exception e) {
        }
    }

    public static void changeMenuIconColor(Menu menu, @ColorInt int color) {
        for (int i = 0; i < menu.size(); i++) {
            Drawable drawable = menu.getItem(i).getIcon();
            if (drawable == null) continue;
            drawable.mutate();
            drawable.setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        }
    }

    public static void changeOverflowMenuIconColor(Toolbar toolbar, @ColorInt int color) {
        try {
            Drawable drawable = toolbar.getOverflowIcon();
            drawable.mutate();
            drawable.setColorFilter(color, PorterDuff.Mode.SRC_ATOP);
        } catch (Exception e) {
        }
    }

    public static boolean isConnect(Context context) {
        try {
            ConnectivityManager connectivityManager = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
            if (activeNetworkInfo != null) {
                if (activeNetworkInfo.isConnected() || activeNetworkInfo.isConnectedOrConnecting()) {
                    return true;
                } else {
                    return false;
                }
            } else {
                return false;
            }
        } catch (Exception e) {
            return false;
        }
    }

    public static int getStatusBarHeight(Context context) {
        int height;
        Resources myResources = context.getResources();
        int idStatusBarHeight = myResources.getIdentifier("status_bar_height", "dimen", "android");
        if (idStatusBarHeight > 0) {
            height = context.getResources().getDimensionPixelSize(idStatusBarHeight);
        } else {
            height = 0;
        }
        return height;
    }

    public static String getFormattedDateSimple(Long dateTime) {
        SimpleDateFormat newFormat = new SimpleDateFormat("dd MMM yy hh:mm");
        return newFormat.format(new Date(dateTime));
    }

    public static void rateAction(Activity activity) {
        String general_market_android = AppConfig.general.non_playstore_market_android;
        if (TextUtils.isEmpty(general_market_android)) {
            activity.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("http://play.google.com/store/apps/details?id=" + BuildConfig.APPLICATION_ID)));
        } else {
            Tools.directLinkCustomTab(activity, general_market_android);
        }
    }

    public static void checkNotification(Activity activity) {
        NotificationEntity notification = ThisApp.get().getNotification();
        if (notification == null) return;
        if (!TextUtils.isEmpty(notification.link)) {
            if (isPostUrl(AppConfig.general.blogger_url, notification.link)) { // post
                try {
                    Post post = new Post();
                    post.id = getPostIdFromUrl(notification.link);
                    ActivityListingDetail.navigate(activity, post);
                } catch (Exception e) {
                    if (e.getMessage() != null) Log.e("Error", e.getMessage());
                }
            } else if (isPageUrl(AppConfig.general.blogger_url, notification.link)) { // page
                Page page = new Page();
                page.id = getPageIdFromUrl(notification.link);
                ActivityUpdateDetails.navigate(activity, page);
            } else {
                // other link
                Tools.directLinkCustomTab(activity, notification.link);
            }
        }

        ThisApp.get().setNotification(null);
    }

    public static String getHostName(String url) {
        try {
            URI uri = new URI(url);
            String new_url = uri.getHost();
            if (!new_url.startsWith("www.")) new_url = "www." + new_url;
            return new_url;
        } catch (URISyntaxException e) {
            e.printStackTrace();
            return url;
        }
    }

    public static int dpToPx(Context c, int dp) {
        Resources r = c.getResources();
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, r.getDisplayMetrics()));
    }

    public static void directLinkCustomTab(Activity activity, String url) {
        if (!URLUtil.isValidUrl(url)) {
            Toast.makeText(activity, R.string.cannot_open_url, Toast.LENGTH_LONG).show();
            return;
        }
        if (!AppConfig.general.open_link_in_app) {
            Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
            activity.startActivity(browserIntent);
            return;
        }
        int color = ResourcesCompat.getColor(activity.getResources(), R.color.primary, null);
        int secondaryColor = ResourcesCompat.getColor(activity.getResources(), R.color.accent, null);

        CustomTabsIntent.Builder intentBuilder = new CustomTabsIntent.Builder();
        CustomTabColorSchemeParams defaultColors = new CustomTabColorSchemeParams.Builder()
                .setToolbarColor(color)
                .setSecondaryToolbarColor(secondaryColor)
                .build();
        intentBuilder.setDefaultColorSchemeParams(defaultColors);
        intentBuilder.setShowTitle(true);
        intentBuilder.setUrlBarHidingEnabled(true);

        CustomTabsHelper.openCustomTab(activity, intentBuilder.build(), Uri.parse(url), (activity1, uri) -> {
            ActivityWebView.navigate(activity1, uri.toString());
        });
    }

    public static void hideKeyboard(Activity activity) {
        View view = activity.getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager) activity.getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    public static int getScreenWidth() {
        return Resources.getSystem().getDisplayMetrics().widthPixels;
    }

    public static void goToNotificationSettings(Activity activity) {
        Intent intent = new Intent();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            intent.setAction(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, BuildConfig.APPLICATION_ID);
        } else {
            intent.setAction("android.settings.APP_NOTIFICATION_SETTINGS");
            intent.putExtra("app_package", BuildConfig.APPLICATION_ID);
            intent.putExtra("app_uid", activity.getApplicationInfo().uid);
        }
        activity.startActivity(intent);
    }

    public static void aboutAction(Activity activity) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle(activity.getString(R.string.dialog_about_title));
        builder.setMessage(Html.fromHtml(activity.getString(R.string.about_text)));
        builder.setPositiveButton("OK", null);
        builder.show();
    }

    public static void applyTheme(boolean dark) {
        if (dark) {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        } else {
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        }
    }

    private static AppUpdateManager appUpdateManager;
    private static InstallStateUpdatedListener installStateUpdatedListener;

    public static void checkGooglePlayUpdateStopListener() {
        if (appUpdateManager != null)
            appUpdateManager.unregisterListener(installStateUpdatedListener);
    }

    public static void checkGooglePlayUpdate(Activity activity) {
        if (BuildConfig.DEBUG) return;
        installStateUpdatedListener = state -> {
            if (state.installStatus() == InstallStatus.DOWNLOADED) {
                Snackbar snackbar = Snackbar.make(activity.findViewById(android.R.id.content), R.string.update_ready, Snackbar.LENGTH_INDEFINITE);
                snackbar.setAction(R.string.install, view -> {
                    if (appUpdateManager != null) appUpdateManager.completeUpdate();
                });
                snackbar.show();
            } else if (state.installStatus() == InstallStatus.INSTALLED) {
                if (appUpdateManager != null && installStateUpdatedListener != null) {
                    appUpdateManager.unregisterListener(installStateUpdatedListener);
                }
            } else {

            }
        };

        appUpdateManager = AppUpdateManagerFactory.create(activity);
        Task<AppUpdateInfo> appUpdateInfoTask = appUpdateManager.getAppUpdateInfo();
        appUpdateManager.registerListener(installStateUpdatedListener);
        appUpdateInfoTask.addOnSuccessListener(appUpdateInfo -> {
            if (appUpdateInfo.updateAvailability() == UpdateAvailability.UPDATE_AVAILABLE && appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)) {
                try {
                    appUpdateManager.startUpdateFlowForResult(appUpdateInfo, AppUpdateType.FLEXIBLE, activity, 200);
                } catch (IntentSender.SendIntentException e) {
                    e.printStackTrace();
                }
            }
        });
    }


    public static void displayContentHtml(Activity activity, WebView webView, String htmlData) {

        webView.setBackgroundColor(Color.TRANSPARENT);
        webView.getSettings().setDefaultTextEncodingName("UTF-8");
        webView.setFocusableInTouchMode(false);
        webView.setFocusable(false);

        if (!AppConfig.general.enable_text_selection) {
            webView.setOnLongClickListener(v -> true);
            webView.setLongClickable(false);
        }

        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(true);
        int defaultFontSize = webView.getSettings().getDefaultFontSize();
        int fontSize = Math.round(defaultFontSize * 80 / 100f);
        webView.getSettings().setDefaultFontSize(fontSize);

        String bgParagraph;
        String mimeType = "text/html; charset=UTF-8";
        String encoding = "utf-8";

        if (SharedPref.get().isDarkTheme()) {
            bgParagraph = "<style type=\"text/css\">body{color: #eeeeee;} a{color:#ffffff; font-weight:bold;}";
        } else {
            bgParagraph = "<style type=\"text/css\">body{color: #2C3240;} a{color:#1e88e5; font-weight:bold;}";
        }

        String fontStyleDefault = "<style type=\"text/css\">@font-face {font-family: MyFont;src: url(\"file:///android_asset/font/custom_font.ttf\")}body {font-family: MyFont;font-size: medium; text-align: left;}</style>";

        String textDefault = "<html><head>"
                + fontStyleDefault
                + "<style>img{max-width:100%;height:auto;} figure{max-width:100%;height:auto;} iframe{width:100%;}</style> "
                + bgParagraph
                + "</style></head>"
                + "<body>"
                + htmlData
                + "</body></html>";

        String textRtl = "<html dir='rtl'><head>"
                + fontStyleDefault
                + "<style>img{max-width:100%;height:auto;} figure{max-width:100%;height:auto;} iframe{width:100%;}</style> "
                + bgParagraph
                + "</style></head>"
                + "<body>"
                + htmlData
                + "</body></html>";

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                if (url.endsWith(".jpg") || url.endsWith(".jpeg") || url.endsWith(".png") || url.endsWith(".gif")) {
                    ActivityFullScreenImage.navigate(activity, url);
                } else {
                    Tools.directLinkCustomTab(activity, url);
                }
                return true;
            }
        });

        if (AppConfig.RTL_LAYOUT) {
            webView.loadDataWithBaseURL(null, textRtl, mimeType, encoding, null);
        } else {
            webView.loadDataWithBaseURL(null, textDefault, mimeType, encoding, null);
        }
    }


    public static void cleanBeginningWhiteSpace(Document htmlData) {
        htmlData.traverse(new NodeVisitor() {
            @Override
            public void head(Node node, int depth) {
                // Remove empty tags
                if (node instanceof Element && ((Element) node).isBlock() && ((Element) node).childNodes().isEmpty()) {
                    node.remove();
                }

                // Remove line breaks until text is found
                if (node.nodeName().equals("br") && !hasTextAfter(node)) {
                    node.remove();
                }
            }

            @Override
            public void tail(Node node, int depth) {
                // Do nothing
            }

            // Helper method to check if there is any text node after the given node
            private boolean hasTextAfter(Node node) {
                Node next = node.nextSibling();

                while (next != null) {
                    if (next instanceof Element) {
                        if (((Element) next).isBlock() && !((Element) next).childNodes().isEmpty()) {
                            // Found a non-empty block element, so there must be text after the current node
                            return true;
                        } else {
                            // Continue checking the child nodes of the current element
                            next = next.childNodeSize() > 0 ? next.childNode(0) : null;
                        }
                    } else if (next instanceof org.jsoup.nodes.TextNode) {
                        // Found a text node after the current node
                        return true;
                    } else {
                        // Continue checking the next sibling node
                        next = next.nextSibling();
                    }
                }

                // Reached the end of the DOM tree without finding any text node after the current node
                return false;
            }
        });

        // Remove all leading <br> tags
        Element body = htmlData.body();
        while (!body.children().isEmpty() && body.child(0).tagName().equals("br")) {
            body.child(0).remove();
        }
    }

    public static void showToastCustom(Context context, @StringRes int resId) {
        Toast toast = Toast.makeText(context, resId, Toast.LENGTH_SHORT);
        toast.show();
    }

    public static String getDateTime(String datetime, boolean simple) {
        try {
            Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSZ", Locale.getDefault()).parse(datetime);
            return getDateSimple(date, simple);
        } catch (ParseException e) {
            e.printStackTrace();
            return datetime;
        }
    }

    public static String getDateSimple(Date date, boolean simple) {
        String format = simple ? "dd MMM yyyy" : "dd MMMM yyyy, hh:mm";
        SimpleDateFormat newFormat = new SimpleDateFormat(format, Locale.getDefault());
        return newFormat.format(date);
    }

    public static String getPostIdFromUrl(String url) {
        String[] parts = url.split("/");
        String postId = parts[parts.length - 1];
        postId = postId.replaceAll("\\.html$", "");
        return postId;
    }

    public static String getPageIdFromUrl(String url) {
        return url;
    }

    public static boolean isPostOrPageUrl(String bloggerUrl, String url) {
        return isPostUrl(bloggerUrl, url) || isPageUrl(bloggerUrl, url);
    }

    public static boolean isPostUrl(String bloggerUrl, String url) {
        String blogger = escapeRegexAnnotation(bloggerUrl);
        String regex = "https://" + blogger + "/\\d{4}/\\d{2}/[a-zA-Z0-9-]+\\.html";
        return url.matches(regex);
    }

    public static boolean isPageUrl(String bloggerUrl, String url) {
        String blogger = escapeRegexAnnotation(bloggerUrl);
        String regex = "https://" + blogger + "/p/[a-zA-Z0-9-]+\\.html";
        return url.matches(regex);
    }

    public static String escapeRegexAnnotation(String domain) {
        String regex = "[\\\\{}\\[\\]()^$|+*?.]";
        return domain.replaceAll(regex, "\\\\$0");
    }

    public static void actionContact(Activity activity, String title, String contact) {
        if (TextUtils.isEmpty(contact)) {
            contact = AppConfig.general.contact_agent;
        }
        if (isEmail(contact)) {
            Intent emailIntent = new Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:" + contact));
            emailIntent.putExtra(Intent.EXTRA_SUBJECT, activity.getString(R.string.app_name));
            emailIntent.putExtra(Intent.EXTRA_TEXT, AppConfig.general.contact_message_prefix + " : " + title);
            activity.startActivity(Intent.createChooser(emailIntent, "Email"));
            return;
        } else if (isPhoneNumber(contact)) {
            Uri number = Uri.parse("tel:" + contact);
            Intent callIntent = new Intent(Intent.ACTION_DIAL, number);
            activity.startActivity(Intent.createChooser(callIntent, "Phone"));
            return;
        }
        directLinkCustomTab(activity, contact);
    }

    private static boolean isEmail(String input) {
        String EMAIL_REGEX = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+$";
        Pattern pattern = Pattern.compile(EMAIL_REGEX);
        return pattern.matcher(input).matches();
    }

    private static boolean isPhoneNumber(String input) {
        String PHONE_NUMBER_REGEX = "^(\\+\\d{1,3}[- ]?)?\\(?\\d{3}\\)?[- ]?\\d{3}[- ]?\\d{4}$";
        Pattern pattern = Pattern.compile(PHONE_NUMBER_REGEX);
        return pattern.matcher(input).matches();
    }

    public static void methodShare(Activity act, String url) {
        new ShareCompat.IntentBuilder(act)
                .setType("text/plain")
                .setChooserTitle("Share link with: ")
                .setText(url)
                .startChooser();

    }
}
