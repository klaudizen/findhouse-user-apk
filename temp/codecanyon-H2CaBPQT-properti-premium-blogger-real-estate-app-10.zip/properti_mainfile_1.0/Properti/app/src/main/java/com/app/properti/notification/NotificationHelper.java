package com.app.properti.notification;

import android.content.Context;
import android.content.Intent;

import com.app.properti.AppConfig;
import com.app.properti.BuildConfig;
import com.app.properti.R;
import com.app.properti.activity.ActivityDialogNotification;
import com.app.properti.activity.ActivitySplash;
import com.app.properti.room.AppDatabase;
import com.app.properti.room.DAO;
import com.app.properti.room.table.NotificationEntity;
import com.onesignal.OSNotification;
import com.onesignal.OneSignal;

public class NotificationHelper {

    private static final int MAX_PERMISSION_TRY = 3;
    private static int permission_try_count = 0;

    public static void init(Context context) {
        oneSignalInit(context);
    }

    public static void oneSignalInit(Context context) {
        if (BuildConfig.DEBUG) {
            OneSignal.setLogLevel(OneSignal.LOG_LEVEL.VERBOSE, OneSignal.LOG_LEVEL.NONE);
        }

        // init one signal with client data
        OneSignal.initWithContext(context);
        OneSignal.setAppId(AppConfig.notification.notif_one_signal_appid);
        OneSignal.sendTag("APP", context.getResources().getString(R.string.app_name));

        // handle when use click notification
        onOneSignalOpenNotification(context);
    }

    public static void showNotificationPermission() {
        permission_try_count++;
        if (permission_try_count < MAX_PERMISSION_TRY) {
            return;
        }
        permission_try_count = 0;
        OneSignal.promptForPushNotifications();
    }

    public static void onOneSignalOpenNotification(Context context) {
        DAO dao = AppDatabase.getDb(context).get();
        OneSignal.setNotificationOpenedHandler(result -> {
            OSNotification notification = result.getNotification();
            NotificationEntity notificationEntity = dao.getNotification(notification.getSentTime());
            Intent intent = new Intent(context, ActivitySplash.class);
            if (notificationEntity != null) {
                intent = ActivityDialogNotification.navigateBase(context, notificationEntity, true);
            }
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);

        });

    }


}