package com.app.properti.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.app.properti.AppConfig;
import com.app.properti.R;
import com.app.properti.data.ThisApp;
import com.app.properti.databinding.ActivitySettingBinding;
import com.app.properti.room.DAO;
import com.app.properti.utils.Tools;

public class ActivitySetting extends AppCompatActivity {

    public static void navigate(Activity activity) {
        Intent i = new Intent(activity, ActivitySetting.class);
        activity.startActivity(i);
    }

    public ActivitySettingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySettingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initToolbar();
        initComponent();

        Tools.RTLMode(getWindow());
    }

    private void initToolbar() {
        binding.toolbarMenuClose.setOnClickListener(v -> finish());
    }

    private void initComponent() {
        binding.actionSwitchTheme.setOnClickListener(view -> actionTheme());

        binding.actionTheme.setOnClickListener(view -> actionTheme());

        binding.actionNotification.setOnClickListener(view -> ActivityNotification.navigate(this));

        binding.actionNotificationSetting.setOnClickListener(view -> Tools.goToNotificationSettings(this));

        binding.actionPrivacy.setOnClickListener(view -> Tools.directLinkCustomTab(this, AppConfig.general.privacy_policy_url));

        binding.actionMoreApp.setOnClickListener(view -> Tools.directLinkCustomTab(this, AppConfig.general.more_apps_url));

        binding.actionRate.setOnClickListener(view -> Tools.rateAction(this));

        binding.actionAboutApp.setOnClickListener(view -> Tools.aboutAction(this));

    }

    private void actionTheme() {
        dialogThemeConfirmation();
    }

    private void validateTheme() {
        if (ThisApp.pref().isDarkTheme()) {
            binding.actionSwitchTheme.setImageResource(R.drawable.ic_toggle_on);
        } else {
            binding.actionSwitchTheme.setImageResource(R.drawable.ic_toggle_off);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        DAO dao = ThisApp.dao();
        binding.notifCount.setText(dao.getNotificationCount() + "");
        int notifCount = ThisApp.dao().getNotificationUnreadCount();
        binding.read.setVisibility(notifCount > 0 ? View.VISIBLE : View.INVISIBLE);
    }

    public void dialogThemeConfirmation() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(R.string.change_theme_title);
        builder.setMessage(R.string.change_theme_confirmation);
        builder.setPositiveButton(R.string.CONTINUE, (di, i) -> {
            di.dismiss();
            ThisApp.pref().setDarkTheme(!ThisApp.pref().isDarkTheme());
            Tools.applyTheme(ThisApp.pref().isDarkTheme());
            validateTheme();
            Tools.restartApp(ActivitySetting.this);
        });
        builder.setNegativeButton(R.string.CANCEL, null);
        builder.show();
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
}

