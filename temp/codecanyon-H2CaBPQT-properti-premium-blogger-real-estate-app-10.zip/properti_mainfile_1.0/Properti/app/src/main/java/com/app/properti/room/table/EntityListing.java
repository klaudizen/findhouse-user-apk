package com.app.properti.room.table;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.app.properti.model.Post;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.Serializable;
import java.util.List;

@Entity(tableName = "listing")
public class EntityListing implements Serializable {

    @PrimaryKey
    @NonNull
    public String id;

    @ColumnInfo(name = "type")
    public String type;

    @ColumnInfo(name = "title")
    public String title;

    @ColumnInfo(name = "price")
    public String price;

    @ColumnInfo(name = "address")
    public String address;

    @ColumnInfo(name = "contact")
    public String contact;

    @ColumnInfo(name = "bed_room")
    public String bed_room;

    @ColumnInfo(name = "bath_room")
    public String bath_room;

    @ColumnInfo(name = "kitchen_room")
    public String kitchen_room;

    @ColumnInfo(name = "cars")
    public String cars;

    @ColumnInfo(name = "area_size")
    public String area_size;

    @ColumnInfo(name = "content")
    public String content;

    @ColumnInfo(name = "link")
    public String link;

    @ColumnInfo(name = "image")
    public String image;

    @ColumnInfo(name = "category")
    public String category;

    @ColumnInfo(name = "images")
    public String images;

    @ColumnInfo(name = "published")
    public String published;

    @ColumnInfo(name = "updated")
    public String updated;

    @ColumnInfo(name = "saved_date")
    private Long saved_date;

    @NonNull
    public String getId() {
        return id;
    }

    public void setId(@NonNull String id) {
        this.id = id;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getBed_room() {
        return bed_room;
    }

    public void setBed_room(String bed_room) {
        this.bed_room = bed_room;
    }

    public String getBath_room() {
        return bath_room;
    }

    public void setBath_room(String bath_room) {
        this.bath_room = bath_room;
    }

    public String getKitchen_room() {
        return kitchen_room;
    }

    public void setKitchen_room(String kitchen_room) {
        this.kitchen_room = kitchen_room;
    }

    public String getCars() {
        return cars;
    }

    public void setCars(String cars) {
        this.cars = cars;
    }

    public String getArea_size() {
        return area_size;
    }

    public void setArea_size(String area_size) {
        this.area_size = area_size;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getImages() {
        return images;
    }

    public void setImages(String images) {
        this.images = images;
    }

    public String getPublished() {
        return published;
    }

    public void setPublished(String published) {
        this.published = published;
    }

    public String getUpdated() {
        return updated;
    }

    public void setUpdated(String updated) {
        this.updated = updated;
    }

    public Long getSaved_date() {
        return saved_date;
    }

    public void setSaved_date(Long saved_date) {
        this.saved_date = saved_date;
    }

    public static EntityListing entity(Post data) {
        EntityListing entity = new EntityListing();
        entity.setId(data.id);
        entity.setType(data.type);
        entity.setTitle(data.title);

        entity.setPrice(data.price);
        entity.setAddress(data.address);
        entity.setContact(data.contact);
        entity.setBed_room(data.bed_room);
        entity.setBath_room(data.bath_room);
        entity.setKitchen_room(data.kitchen_room);
        entity.setCars(data.cars);
        entity.setArea_size(data.area_size);

        entity.setContent(data.content);
        entity.setLink(data.link);
        entity.setImage(data.image);
        entity.setCategory(new Gson().toJson(data.category));
        entity.setImages(new Gson().toJson(data.images));
        entity.setPublished(data.published);
        entity.setUpdated(data.updated);

        entity.setSaved_date(System.currentTimeMillis());
        return entity;
    }

    public Post original() {
        Post l = new Post();
        l.id = getId();
        l.type = getType();
        l.title = getTitle();

        l.price = getPrice();
        l.address = getAddress();
        l.contact = getContact();
        l.bed_room = getBed_room();
        l.bath_room = getBath_room();
        l.kitchen_room = getKitchen_room();
        l.cars = getCars();
        l.area_size = getArea_size();

        l.content = getContent();
        l.link = getLink();
        l.image = getImage();
        l.images = new Gson().fromJson(getImages(), new TypeToken<List<String>>() {}.getType());
        l.category = new Gson().fromJson(getCategory(), new TypeToken<List<String>>() {}.getType());
        l.published = getPublished();
        l.updated = getUpdated();

        return l;
    }
}
