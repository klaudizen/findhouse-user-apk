package com.app.properti.activity;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.app.properti.AppConfig;
import com.app.properti.R;
import com.app.properti.advertise.AdNetworkHelper;
import com.app.properti.data.ThisApp;
import com.app.properti.databinding.ActivityMainBinding;
import com.app.properti.fragment.FragmentCategory;
import com.app.properti.fragment.FragmentHome;
import com.app.properti.fragment.FragmentSaved;
import com.app.properti.fragment.FragmentUpdate;
import com.app.properti.notification.NotificationHelper;
import com.app.properti.utils.Tools;

public class ActivityMain extends AppCompatActivity {

    private ActivityMainBinding binding;
    private FragmentHome fragmentHome;
    private FragmentCategory fragmentCategory;
    private FragmentUpdate fragmentUpdate;
    private FragmentSaved fragmentSaved;
    private Fragment selectedFragment;
    private FragmentManager fm;

    private Handler handler = new Handler(Looper.getMainLooper());
    private static ActivityMain instance;

    public static ActivityMain getInstance() {
        return instance;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        instance = this;
        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        initComponent();

        // set default fragment
        selectedFragment = fragmentHome;
        displayFragment(R.id.nav_home, getString(R.string.menu_home));

        prepareAds();

        Tools.checkNotification(this);
        Tools.RTLMode(getWindow());
    }

    private void initComponent() {
        setSupportActionBar(binding.toolbar);
        ActionBar actionBar = getSupportActionBar();
        actionBar.setTitle(null);
        Tools.changeOverflowMenuIconColor(binding.toolbar, getResources().getColor(R.color.toolbarIconText));

        if (AppConfig.TINT_LOGO) {
            binding.logo.setColorFilter(ContextCompat.getColor(this, R.color.logoColor));
        }

        fm = getSupportFragmentManager();

        fragmentHome = FragmentHome.instance();
        fragmentCategory = FragmentCategory.instance();
        fragmentUpdate = FragmentUpdate.instance();
        fragmentSaved = FragmentSaved.instance();

        fm.beginTransaction().add(R.id.frame_layout, fragmentHome, getString(R.string.menu_home)).commit();
        fm.beginTransaction().add(R.id.frame_layout, fragmentCategory, getString(R.string.menu_category)).hide(fragmentCategory).commit();
        fm.beginTransaction().add(R.id.frame_layout, fragmentUpdate, getString(R.string.menu_update)).hide(fragmentUpdate).commit();
        fm.beginTransaction().add(R.id.frame_layout, fragmentSaved, getString(R.string.menu_saved)).hide(fragmentSaved).commit();

        binding.navigation.setOnItemSelectedListener(item -> {
            displayFragment(item.getItemId(), item.getTitle().toString());
            return true;
        });

        // listener for hide toolbar and bottom nav
        binding.appbarLayout.addOnOffsetChangedListener((appBarLayout, verticalOffset) -> {
            int offset = Math.abs(verticalOffset), range = appBarLayout.getTotalScrollRange();
            int heightMax = binding.lytBarContent.getHeight();
            if (range <= 0) return;
            int translationY = (offset * heightMax) / range;
            binding.lytBar.setTranslationY(translationY);
        });

        binding.toolbarMenuMore.setOnClickListener(v -> {
            ActivitySetting.navigate(this);
            showInterstitialAd();
        });

        binding.toolbarMenuNotif.setOnClickListener(v -> {
            ActivityNotification.navigate(this);
        });
    }


    public void displayFragment(int id, String title) {
        if (id == R.id.nav_home) {
            fm.beginTransaction().hide(selectedFragment).show(fragmentHome).commit();
            selectedFragment = fragmentHome;
        } else if (id == R.id.nav_category) {
            fm.beginTransaction().hide(selectedFragment).show(fragmentCategory).commit();
            selectedFragment = fragmentCategory;
        } else if (id == R.id.nav_update) {
            fm.beginTransaction().hide(selectedFragment).show(fragmentUpdate).commit();
            selectedFragment = fragmentUpdate;
        } else if (id == R.id.nav_saved) {
            fm.beginTransaction().hide(selectedFragment).show(fragmentSaved).commit();
            fragmentSaved.updateData();
            selectedFragment = fragmentSaved;
        }
        binding.title.setText(title);
        binding.navigation.getMenu().findItem(id).setChecked(true);
    }

    @Override
    public void onBackPressed() {
        if (fm.getBackStackEntryCount() > 0) {
            fm.popBackStack();
        } else if (selectedFragment != fragmentHome) {
            displayFragment(R.id.nav_home, getString(R.string.menu_home));
        } else {
            doExitApp();
        }
    }

    private long exitTime = 0;

    public void doExitApp() {
        if ((System.currentTimeMillis() - exitTime) > 2000) {
            Tools.showToastCustom(this, R.string.press_again_exit_app);
            exitTime = System.currentTimeMillis();
            binding.appbarLayout.setExpanded(true, true);
        } else {
            finish();
        }
    }

    static boolean active = false;

    @Override
    public void onStart() {
        super.onStart();
        active = true;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        active = false;
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshSaved();

        int notifCount = ThisApp.dao().getNotificationUnreadCount();
        binding.notifBadge.setVisibility(notifCount > 0 ? View.VISIBLE : View.INVISIBLE);

        NotificationHelper.showNotificationPermission();
    }

    @Override
    protected void onPostCreate(@Nullable Bundle savedInstanceState) {
        super.onPostCreate(savedInstanceState);
        Tools.checkGooglePlayUpdate(this);
    }

    @Override
    protected void onStop() {
        super.onStop();
        Tools.checkGooglePlayUpdateStopListener();
    }

    public void refreshSaved() {
        fragmentSaved.need_update = true;
        fragmentSaved.updateData();
    }

    private AdNetworkHelper adNetworkHelper;

    private void prepareAds() {
        adNetworkHelper = new AdNetworkHelper(this);
        adNetworkHelper.init();
        adNetworkHelper.updateConsentStatus();
        adNetworkHelper.loadBannerAd(AppConfig.ads.ad_main_banner);
        adNetworkHelper.loadInterstitialAd(AppConfig.ads.ad_main_interstitial);
    }

    public void showInterstitialAd() {
        adNetworkHelper.showInterstitialAd(AppConfig.ads.ad_main_interstitial);
    }
}