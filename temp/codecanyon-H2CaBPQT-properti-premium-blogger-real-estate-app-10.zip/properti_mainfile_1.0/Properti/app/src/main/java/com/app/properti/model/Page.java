package com.app.properti.model;

import android.text.TextUtils;

import java.io.Serializable;

public class Page implements Serializable {

    public String id;
    public String type;
    public String title;
    public String published;
    public String updated;
    public String content;
    public String brief;
    public String link;
    public String image;

    public boolean isDraft() {
        return TextUtils.isEmpty(title);
    }

}
