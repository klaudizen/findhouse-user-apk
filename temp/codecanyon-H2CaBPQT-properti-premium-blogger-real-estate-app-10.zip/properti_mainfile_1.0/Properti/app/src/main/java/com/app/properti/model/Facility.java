package com.app.properti.model;

import java.io.Serializable;

public class Facility implements Serializable {

    public int icon;
    public String title;

    public Facility() {
    }

    public Facility(int icon, String title) {
        this.icon = icon;
        this.title = title;
    }
}
