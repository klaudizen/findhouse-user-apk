package com.app.properti.model;

public class SectionSearch {

}
