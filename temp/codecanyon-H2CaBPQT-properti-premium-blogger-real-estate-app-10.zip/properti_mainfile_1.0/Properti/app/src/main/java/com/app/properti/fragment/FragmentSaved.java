package com.app.properti.fragment;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.app.properti.AppConfig;
import com.app.properti.R;
import com.app.properti.adapter.AdapterListing;
import com.app.properti.data.ThisApp;
import com.app.properti.databinding.FragmentSavedBinding;
import com.app.properti.model.Post;
import com.app.properti.room.table.EntityListing;

import java.util.ArrayList;
import java.util.List;

public class FragmentSaved extends Fragment {

    private FragmentSavedBinding binding;
    private AdapterListing adapter;
    public boolean need_update = true;

    public static FragmentSaved instance() {
        return new FragmentSaved();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentSavedBinding.inflate(inflater, container, false);
        initComponent();
        return binding.getRoot();
    }

    private void initComponent() {
        binding.recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));

        //set data and list adapter
        adapter = new AdapterListing(getActivity(), binding.recyclerView, AppConfig.general.listing_pagination_count);
        binding.recyclerView.setAdapter(adapter);

        binding.swipeRefresh.setOnRefreshListener(() -> {
            adapter.resetListData();
            requestAction();
        });
    }

    private void requestAction() {
        showNoItemView(false);
        swipeProgress(true);
        new Handler(Looper.getMainLooper()).postDelayed(() -> request(), 200);
    }

    private void request() {
        List<EntityListing> entityListings = ThisApp.dao().getAllListing();
        displayResult(entityListings);
    }

    private void showNoItemView(boolean show) {
        ((TextView) binding.lytFailed.findViewById(R.id.failed_subtitle)).setText(getString(R.string.empty_state_no_data));
        if (show) {
            binding.lytFailed.setVisibility(View.VISIBLE);
        } else {
            binding.lytFailed.setVisibility(View.GONE);
        }
    }

    private void swipeProgress(final boolean show) {
        binding.swipeRefresh.post(() -> binding.swipeRefresh.setRefreshing(show));
        if (!show) {
            binding.recyclerView.setVisibility(View.VISIBLE);
            binding.shimmer.setVisibility(View.GONE);
            binding.shimmer.stopShimmer();
            return;
        }
        binding.recyclerView.setVisibility(View.GONE);
        binding.shimmer.setVisibility(View.VISIBLE);
        binding.shimmer.startShimmer();
    }

    private void displayResult(final List<EntityListing> entityListings) {
        List<Post> items = new ArrayList<>();
        for (EntityListing e : entityListings) {
            items.add(e.original());
        }
        adapter.resetListData();
        adapter.insertData(items);
        swipeProgress(false);
        showNoItemView(adapter.getItemCount() == 0);
    }

    public void updateData() {
        if (need_update) {
            requestAction();
            need_update = false;
        }
    }

}