package com.app.properti.adapter;

import android.content.Context;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Handler;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.app.properti.R;
import com.app.properti.data.ThisApp;
import com.app.properti.databinding.ItemHomeCategoryBinding;
import com.app.properti.databinding.ItemListingBinding;
import com.app.properti.databinding.ItemLoadingBinding;
import com.app.properti.databinding.ItemSectionCategoryBinding;
import com.app.properti.databinding.ItemSectionSearchBinding;
import com.app.properti.databinding.ItemSectionSliderBinding;
import com.app.properti.model.CategoryHome;
import com.app.properti.model.Page;
import com.app.properti.model.Post;
import com.app.properti.model.SectionCategory;
import com.app.properti.model.SectionSearch;
import com.app.properti.model.SectionSlider;
import com.app.properti.room.table.EntityListing;
import com.app.properti.utils.Tools;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class AdapterListing extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    public enum ActionType {
        SEARCH, ITEM, CATEGORY, CATEGORY_ALL, SLIDER, SAVED
    }

    private final Context ctx;
    private List<Object> items = new ArrayList<>();
    private List<Object> items_temp = new ArrayList<>();

    private final int VIEW_SEARCH = 100;
    private final int VIEW_ITEM = 200;
    private final int VIEW_TOP_TAB = 300;
    private final int VIEW_SLIDER = 400;
    private final int VIEW_PROG = 0;
    private boolean loading = true;
    private String status;
    private int page = 0;

    private AdapterListener<Object> listener;

    public void setListener(AdapterListener<Object> listener) {
        this.listener = listener;
    }

    // Provide a suitable constructor (depends on the kind of dataset)
    public AdapterListing(Context context, RecyclerView view, int page) {
        this.page = page;
        ctx = context;
        lastItemViewDetector(view);
    }

    public class OriginalViewHolder extends RecyclerView.ViewHolder {
        ItemListingBinding binding;

        public OriginalViewHolder(@NonNull ItemListingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public class SectionSearchViewHolder extends RecyclerView.ViewHolder {
        ItemSectionSearchBinding binding;

        public SectionSearchViewHolder(@NonNull ItemSectionSearchBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public class SectionSliderViewHolder extends RecyclerView.ViewHolder {
        ItemSectionSliderBinding binding;

        public SectionSliderViewHolder(@NonNull ItemSectionSliderBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public class SectionCategoryViewHolder extends RecyclerView.ViewHolder {
        ItemSectionCategoryBinding binding;

        public SectionCategoryViewHolder(@NonNull ItemSectionCategoryBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    public static class ProgressViewHolder extends RecyclerView.ViewHolder {
        ItemLoadingBinding binding;

        public ProgressViewHolder(@NonNull ItemLoadingBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerView.ViewHolder vh;

        if (viewType == VIEW_SEARCH) {
            ItemSectionSearchBinding v = ItemSectionSearchBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            vh = new SectionSearchViewHolder(v);
        } else if (viewType == VIEW_ITEM) {
            ItemListingBinding v = ItemListingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            vh = new OriginalViewHolder(v);
        } else if (viewType == VIEW_TOP_TAB) {
            ItemSectionCategoryBinding v = ItemSectionCategoryBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            vh = new SectionCategoryViewHolder(v);
        } else if (viewType == VIEW_SLIDER) {
            ItemSectionSliderBinding v = ItemSectionSliderBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            vh = new SectionSliderViewHolder(v);
        } else {
            ItemLoadingBinding v = ItemLoadingBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            vh = new ProgressViewHolder(v);
        }
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position, @NonNull List<Object> payloads) {
        super.onBindViewHolder(holder, position, payloads);

    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int pos) {
        int position = holder.getAdapterPosition();
        Object obj = items.get(position);
        if (holder instanceof OriginalViewHolder) {
            OriginalViewHolder v = (OriginalViewHolder) holder;
            final Post post = (Post) obj;
            v.binding.title.setText(post.title);
            Tools.displayImage(ctx, v.binding.image, post.image);

            v.binding.price.setVisibility(TextUtils.isEmpty(post.price) ? View.GONE : View.VISIBLE);
            v.binding.price.setText(TextUtils.isEmpty(post.price) ? "" : post.price);

            v.binding.address.setVisibility(TextUtils.isEmpty(post.address) ? View.GONE : View.VISIBLE);
            v.binding.address.setText(TextUtils.isEmpty(post.address) ? "" : post.address);

            setFacilities(v.binding.lytBathRoom, v.binding.bathRoom, post.bath_room);
            setFacilities(v.binding.lytBedRoom, v.binding.bedRoom, post.bed_room);
            setFacilities(v.binding.lytCar, v.binding.car, post.cars);
            setFacilities(v.binding.lytArea, v.binding.area, post.area_size);

            v.binding.buttonSaved.setOnClickListener(view -> {
                toggleSaved(post, position);
                if (listener == null) return;
                listener.onClick(view, ActionType.SAVED.name(), post, position);
            });

            if (ThisApp.dao().getListing(post.id) == null) {
                v.binding.buttonSaved.setImageResource(R.drawable.ic_bookmark_border);
            } else {
                v.binding.buttonSaved.setImageResource(R.drawable.ic_bookmark);
            }

            v.binding.lytParent.setOnClickListener(view -> {
                if (listener == null) return;
                listener.onClick(view, ActionType.ITEM.name(), post, position);
            });
        } else if (holder instanceof SectionSliderViewHolder) {
            SectionSlider sliderList = (SectionSlider) obj;
            final SectionSliderViewHolder v = (SectionSliderViewHolder) holder;
            final AdapterImageSlider adapterSlider = new AdapterImageSlider(ctx);
            adapterSlider.setItems(sliderList.pages);
            v.binding.viewPager.setAdapter(adapterSlider);
            v.binding.viewPager.setCurrentItem(1, false);

            int sliderSize = sliderList.pages.size() + 2;
            v.binding.viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
                @Override
                public void onPageScrollStateChanged(int state) {
                    super.onPageScrollStateChanged(state);
                    if (state == ViewPager2.SCROLL_STATE_IDLE) {
                        if (v.binding.viewPager.getCurrentItem() == sliderSize - 1) {
                            v.binding.viewPager.setCurrentItem(1, false);
                        } else if (v.binding.viewPager.getCurrentItem() == 0) {
                            v.binding.viewPager.setCurrentItem(sliderSize - 2, false);
                        }

                        // set indicator
                        int pagePos = v.binding.viewPager.getCurrentItem() - 1;
                        if (pagePos >= 0 && pagePos < sliderSize - 2) {
                            addBottomDots(v.binding.layoutDots, sliderSize - 2, pagePos);
                        }
                    }
                }
            });

            adapterSlider.setOnItemClickListener((view, page) -> {
                if (listener == null) return;
                listener.onClick(view, ActionType.SLIDER.name(), page, position);
            });

            addBottomDots(v.binding.layoutDots, sliderSize - 2, 0);
            startAutoSlider(v.binding.viewPager);

        } else if (holder instanceof SectionCategoryViewHolder) {
            final SectionCategory sectionCategory = (SectionCategory) obj;
            SectionCategoryViewHolder v = (SectionCategoryViewHolder) holder;
            v.binding.lytParent.removeAllViews();
            int index = 0;
            for (CategoryHome cat : sectionCategory.categories) {
                index++;
                ItemHomeCategoryBinding viewItem = ItemHomeCategoryBinding.inflate(LayoutInflater.from(ctx));
                viewItem.title.setText(cat.title);
                viewItem.icon.setImageResource(cat.icon);
                viewItem.lytIcon.setOnClickListener(view -> {
                    if (listener == null) return;
                    listener.onClick(view, ActionType.CATEGORY.name(), cat.category, position);
                });
                v.binding.lytParent.addView(viewItem.getRoot());
                if (index < sectionCategory.categories.size()) {
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.MATCH_PARENT);
                    params.weight = 1.0f;
                    View spacer = new View(ctx);
                    spacer.setLayoutParams(params);
                    v.binding.lytParent.addView(spacer);
                }
            }
        } else if (holder instanceof SectionSearchViewHolder) {
            final SectionSearchViewHolder v = (SectionSearchViewHolder) holder;
            v.binding.searchInput.setOnClickListener(view -> {
                if (listener == null) return;
                listener.onClick(view, ActionType.SEARCH.name(), null, -1);
            });
        } else {

            final ProgressViewHolder v = (ProgressViewHolder) holder;
            v.binding.progressLoading.setVisibility(status == null ? View.VISIBLE : View.GONE);
            v.binding.statusLoading.setVisibility(status == null ? View.GONE : View.VISIBLE);

            if (status == null) return;
            v.binding.statusLoading.setText(status);
            v.binding.statusLoading.setOnClickListener(view -> {
                setLoaded();
                onLoadMore();
            });
        }
    }

    @Override
    public void onViewDetachedFromWindow(@NonNull RecyclerView.ViewHolder holder) {
        super.onViewDetachedFromWindow(holder);
        if (runnable != null) handler.removeCallbacks(runnable);
    }

    // Return the size of your dataset (invoked by the layout manager)
    @Override
    public int getItemCount() {
        return items.size();
    }

    @Override
    public int getItemViewType(int position) {
        Object obj = items.get(position);
        if (obj instanceof SectionSearch) {
            return VIEW_SEARCH;
        } else if (obj instanceof Post) {
            return VIEW_ITEM;
        } else if (obj instanceof SectionCategory) {
            return VIEW_TOP_TAB;
        } else if (obj instanceof SectionSlider) {
            return VIEW_SLIDER;
        } else {
            return VIEW_PROG;
        }
    }

    private boolean toggleSaved(Post listing, int position) {
        boolean saved = false;
        if (ThisApp.dao().getListing(listing.id) == null) {
            ThisApp.dao().insertListing(EntityListing.entity(listing));
            saved = true;
        } else {
            ThisApp.dao().deleteListing(listing.id);
        }
        notifyItemChanged(position);
        return saved;
    }

    private Runnable runnable = null;
    private Handler handler = new Handler();

    private void startAutoSlider(final ViewPager2 viewPager) {
        if (runnable != null) {
            handler.removeCallbacks(runnable);
        }
        runnable = () -> {
            int pos = viewPager.getCurrentItem();
            pos = pos + 1;
            viewPager.setCurrentItem(pos);
            handler.postDelayed(runnable, 3000);
        };
        handler.postDelayed(runnable, 3000);
    }

    private void addBottomDots(LinearLayout layout_dots, int size, int current) {
        ImageView[] dots = new ImageView[size];
        layout_dots.removeAllViews();
        for (int i = 0; i < dots.length; i++) {
            dots[i] = new ImageView(ctx);
            int width_height = ctx.getResources().getDimensionPixelOffset(R.dimen.spacing_6);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(new ViewGroup.LayoutParams(width_height, width_height));
            params.setMargins(6, 0, 6, 0);
            dots[i].setLayoutParams(params);
            dots[i].setImageResource(R.drawable.shape_circle_outline);
            dots[i].setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
            layout_dots.addView(dots[i]);
        }

        if (dots.length > 0) {
            dots[current].setImageResource(R.drawable.shape_circle);
            dots[current].setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);
        }
    }

    public void setCategory(SectionCategory category) {
        this.items.add(category);
        notifyDataSetChanged();
    }

    public void insertData(List<Post> items) {
        setLoaded();
        this.items.addAll(items);
    }

    public void setLoaded() {
        status = null;
        loading = false;
        items.removeAll(Collections.singleton(null));
        notifyDataSetChanged();
    }

    public void clearListProduct() {
        int listing_pos = -1;
        for (int i = 0; i < this.items.size(); i++) {
            if (this.items.get(i) instanceof Post) {
                listing_pos = i;
                break;
            }
        }
        if (listing_pos == -1) return;
        int count = items.size();
        items.subList(listing_pos, count).clear();
        notifyItemRangeRemoved(listing_pos, count);
    }

    public void setLoadingOrFailed(String status) {
        setLoaded();
        this.status = status;
        this.items.add(null);
        notifyItemInserted(getItemCount() - 1);
        loading = true;
    }

    public void resetListData() {
        this.items = new ArrayList<>();
        notifyDataSetChanged();
    }

    public void setSearch() {
        this.items.add(new SectionSearch());
        notifyDataSetChanged();
    }

    public void setSlider(List<Page> items) {
        if (items.isEmpty()) return;
        this.items.add(new SectionSlider(items));
        notifyDataSetChanged();
    }

    boolean scrollDown = false;

    private void lastItemViewDetector(RecyclerView recyclerView) {
        if (recyclerView.getLayoutManager() instanceof LinearLayoutManager) {
            final LinearLayoutManager layoutManager = (LinearLayoutManager) recyclerView.getLayoutManager();
            recyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                @Override
                public void onScrollStateChanged(@NonNull RecyclerView recyclerView, int newState) {
                    super.onScrollStateChanged(recyclerView, newState);
                    if (newState == RecyclerView.SCROLL_STATE_IDLE || !scrollDown) return;
                    int lastPos = layoutManager.findLastVisibleItemPosition();
                    boolean bottom = lastPos >= getItemCount() - page;
                    if (!loading && bottom && listener != null) {
                        onLoadMore();
                    }
                }

                @Override
                public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);
                    scrollDown = dy > 0;
                }
            });
        }
    }

    private void onLoadMore() {
        int current_page = getItemCount() / page;
        listener.onLoadMore(current_page);
        loading = true;
        status = null;
    }

    private void setFacilities(View lyt, TextView label, String data) {
        lyt.setVisibility(TextUtils.isEmpty(data) ? View.GONE : View.VISIBLE);
        label.setText(TextUtils.isEmpty(data) ? "" : data);
    }

}
