FOLDER STRUCTURE :

 +-- Properti/					# Android Project - Open this folder from Android Studio
 +-- documentation.html       	# Open this file using web browser (Chrome, Firefox or Safari)
 
1. Please make sure you was READ documentation page before you ask or contact us.

2. Request about modification (or customization) of the item is NOT available, but you can contact us if want a little change (like name, package, change some text, etc).

3. You can contact us on google hangout dev.dream.space@gmail.com

4. Or you can visit our website : http://dream-space.web.id/


Thanks for purchasing our item :)