package b;

import dreamspace.blogger.sdk.connection.response.RespAtom;
import dreamspace.blogger.sdk.connection.response.RespObject;
import dreamspace.blogger.sdk.listener.RequestListener;
import dreamspace.blogger.sdk.model.ParamList;
import dreamspace.blogger.sdk.model.RespPosts;
import java.util.ArrayList;
import java.util.List;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
/* loaded from: input.aar:classes.jar:b/b.class */
public final class b {

    /* loaded from: input.aar:classes.jar:b/b$a.class */
    public class a implements Callback<RespObject> {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ RequestListener f2a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ ParamList f3b;

        public a(ParamList paramList, RequestListener requestListener) {
            this.f2a = requestListener;
            this.f3b = paramList;
        }

        public final void onResponse(Call<RespObject> call, Response<RespObject> response) {
            RespObject respObject = (RespObject) response.body();
            this.f2a.onFinish();
            if (respObject == null) {
                this.f2a.onFailed(null);
                return;
            }
            this.f2a.onSuccess(c.a.a(respObject, response, this.f3b));
        }

        public final void onFailure(Call<RespObject> call, Throwable th) {
            this.f2a.onFinish();
            this.f2a.onFailed(th.getMessage());
        }
    }

    /* renamed from: b.b$b  reason: collision with other inner class name */
    /* loaded from: input.aar:classes.jar:b/b$b.class */
    public class C0000b implements Callback<RespObject> {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ RequestListener f4a;

        /* renamed from: b  reason: collision with root package name */
        public final /* synthetic */ ParamList f5b;

        public C0000b(ParamList paramList, RequestListener requestListener) {
            this.f4a = requestListener;
            this.f5b = paramList;
        }

        public final void onResponse(Call<RespObject> call, Response<RespObject> response) {
            RespObject respObject = (RespObject) response.body();
            this.f4a.onFinish();
            if (respObject == null) {
                this.f4a.onFailed(null);
                return;
            }
            this.f4a.onSuccess(c.a.a(respObject, response, this.f5b));
        }

        public final void onFailure(Call<RespObject> call, Throwable th) {
            this.f4a.onFinish();
            this.f4a.onFailed(th.getMessage());
        }
    }

    /* loaded from: input.aar:classes.jar:b/b$c.class */
    public class c implements Callback<RespAtom> {

        /* renamed from: a  reason: collision with root package name */
        public final /* synthetic */ RequestListener f6a;

        public c(RequestListener requestListener) {
            this.f6a = requestListener;
        }

        public final void onResponse(Call<RespAtom> call, Response<RespAtom> response) {
            RespAtom.Feed feed;
            RespAtom respAtom = (RespAtom) response.body();
            this.f6a.onFinish();
            if (respAtom != null && (feed = respAtom.feed) != null && feed.category != null) {
                ArrayList arrayList = new ArrayList();
                for (RespAtom.Category category : respAtom.feed.category) {
                    arrayList.add(category.term);
                }
                this.f6a.onSuccess(arrayList);
                return;
            }
            this.f6a.onFailed(null);
        }

        public final void onFailure(Call<RespAtom> call, Throwable th) {
            this.f6a.onFinish();
            this.f6a.onFailed(th.getMessage());
        }
    }

    public static Call b(ParamList paramList, RequestListener<RespPosts> requestListener) {
        String str = paramList.url;
        Call<RespObject> posts = a.b.a(str).getPosts("https://" + str + c.b.a(a.a.a()), paramList.getParams());
        posts.enqueue(new a(paramList, requestListener));
        return posts;
    }

    public static Call a(ParamList paramList, RequestListener<RespPosts> requestListener) {
        String str = paramList.url;
        Call<RespObject> pages = a.b.a(str).getPages("https://" + str + c.b.a(c.b.a()), paramList.getParams());
        pages.enqueue(new C0000b(paramList, requestListener));
        return pages;
    }

    public static Call a(String str, RequestListener<List<String>> requestListener) {
        Call<RespAtom> atom = a.b.a(str).getAtom("https://" + str + c.b.a(c.a.a()));
        atom.enqueue(new c(requestListener));
        return atom;
    }
}
