package b;

import android.util.Base64;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
/* loaded from: input.aar:classes.jar:b/a.class */
public final class a {

    /* renamed from: a  reason: collision with root package name */
    public String f0a;

    /* renamed from: b  reason: collision with root package name */
    public String f1b;

    public a(String str, String str2) {
        this.f0a = str;
        this.f1b = str2;
    }

    public static a a(String str) {
        String str2;
        try {
            String str3 = str2;
            str2 = new String(Base64.decode(Base64.decode(("WkhKbFlXMHVjM0JoWTJVdWEyVjVMZz09XqkaBtH5f8QQqmq").replaceAll("XqkaBtH5f8QQqmq", "").replaceAll("MG7nBzyYGF4fs22", ""), 0), 0));
            if (str2.length() < 16) {
                int length = 16 - str3.length();
                for (int i = 0; i < length; i++) {
                    str3 = str3 + "0";
                }
            } else if (str3.length() > 16) {
                str3 = str3.substring(0, 16);
            }
            String[] split = str.split(":");
            IvParameterSpec ivParameterSpec = new IvParameterSpec(Base64.decode(split[1], 0));
            SecretKeySpec secretKeySpec = new SecretKeySpec(str3.getBytes("ISO-8859-1"), "AES");
            Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
            cipher.init(2, secretKeySpec, ivParameterSpec);
            return new a(new String(cipher.doFinal(Base64.decode(split[0], 0))), null);
        } catch (Exception e) {
            e.printStackTrace();
            return new a(null, e.getMessage());
        }
    }

    public final boolean b() {
        return this.f1b != null;
    }

    public final String a() {
        return this.f0a;
    }
}
