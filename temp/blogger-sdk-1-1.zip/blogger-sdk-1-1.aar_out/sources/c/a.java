package c;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dreamspace.blogger.sdk.connection.response.RespObject;
import dreamspace.blogger.sdk.model.Author;
import dreamspace.blogger.sdk.model.Listing;
import dreamspace.blogger.sdk.model.ParamList;
import dreamspace.blogger.sdk.model.RespPosts;
import java.util.ArrayList;
import retrofit2.Response;
/* loaded from: input.aar:classes.jar:c/a.class */
public final class a {
    public static RespPosts a(RespObject respObject, Response response, ParamList paramList) {
        RespPosts respPosts = new RespPosts();
        respPosts.status = response.code();
        respPosts.messages = response.message();
        respPosts.count = Integer.parseInt(paramList.count);
        respPosts.page = Integer.parseInt(paramList.page);
        respPosts.list = new ArrayList();
        JsonObject asJsonObject = respObject.feed.getAsJsonObject();
        respPosts.count_total = asJsonObject.getAsJsonObject("openSearch$totalResults").get("$t").getAsInt();
        JsonArray asJsonArray = asJsonObject.getAsJsonArray("entry");
        if (asJsonArray != null) {
            for (int i = 0; i < asJsonArray.size(); i++) {
                JsonObject asJsonObject2 = asJsonArray.get(i).getAsJsonObject();
                Listing listing = new Listing();
                if (asJsonObject2 != null) {
                    listing.id = asJsonObject2.getAsJsonObject("id").get("$t").getAsString();
                    listing.type = "posts";
                    listing.title = asJsonObject2.getAsJsonObject("title").get("$t").getAsString();
                    listing.published = asJsonObject2.getAsJsonObject("published").get("$t").getAsString();
                    listing.updated = asJsonObject2.getAsJsonObject("updated").get("$t").getAsString();
                    listing.content = asJsonObject2.getAsJsonObject("content").get("$t").getAsString();
                    JsonArray asJsonArray2 = asJsonObject2.getAsJsonArray("link");
                    listing.link = asJsonArray2.get(asJsonArray2.size() - 1).getAsJsonObject().get("href").getAsString();
                    JsonArray asJsonArray3 = asJsonObject2.getAsJsonArray("category");
                    ArrayList arrayList = new ArrayList();
                    if (asJsonArray3 != null) {
                        for (int i2 = 0; i2 < asJsonArray3.size(); i2++) {
                            arrayList.add(asJsonArray3.get(i2).getAsJsonObject().get("term").getAsString());
                        }
                    }
                    listing.category = arrayList;
                    JsonObject asJsonObject3 = asJsonObject2.getAsJsonArray("author").get(0).getAsJsonObject();
                    Author author = new Author();
                    try {
                        author.name = asJsonObject3.getAsJsonObject("name").get("$t").getAsString();
                        author.uri = asJsonObject3.getAsJsonObject("uri").get("$t").getAsString();
                        author.email = asJsonObject3.getAsJsonObject("email").get("$t").getAsString();
                        author.image = asJsonObject3.getAsJsonObject("gd$image").get("src").getAsString();
                    } catch (Exception unused) {
                        author = null;
                    }
                    listing.author = author;
                }
                respPosts.list.add(listing);
            }
        }
        return respPosts;
    }

    public static String a() {
        return ("TDJGMGIyMHVlRzFzUDNCdmMzUnpQWFJ5ZFdVbVpHVm1ZWFZzZEQxMGNuVmxKbUZzZEQxcWMyOXVKbk4wWVhKMExXbHVaR1Y0UFRFbWJXRjRMWEpsYzNWc2RITTlNQT09SDdByADudCh2E3eLgrk66m45KdtQAb").replaceAll("SDdByADudCh2E3eLgrk66m45KdtQAb", "");
    }
}
