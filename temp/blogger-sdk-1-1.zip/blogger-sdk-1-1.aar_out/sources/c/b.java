package c;

import android.util.Base64;
import java.io.UnsupportedEncodingException;
/* loaded from: input.aar:classes.jar:c/b.class */
public final class b {
    /* JADX WARN: Type inference failed for: r0v1, types: [java.lang.Throwable, byte[]] */
    /* JADX WARN: Type inference failed for: r0v4, types: [java.lang.Throwable, byte[]] */
    public static String a(String str) {
        ?? decode = Base64.decode(str, 0);
        try {
            str = new String((byte[]) decode, "UTF-8");
        } catch (UnsupportedEncodingException unused) {
            decode.printStackTrace();
        }
        ?? decode2 = Base64.decode(str, 0);
        try {
            str = new String((byte[]) decode2, "UTF-8");
        } catch (UnsupportedEncodingException unused2) {
            decode2.printStackTrace();
        }
        return str;
    }

    public static String a() {
        return ("TDJabFpXUnpMM0JoWjJWekwyUmxabUYxYkhRL1lXeDBQV3B6YjI0PQ==SDdByADudCh2E3eLgrk66m45KdtQAb").replaceAll("SDdByADudCh2E3eLgrk66m45KdtQAb", "");
    }
}
