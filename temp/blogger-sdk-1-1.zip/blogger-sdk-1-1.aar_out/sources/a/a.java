package a;
/* loaded from: input.aar:classes.jar:a/a.class */
public final class a {
    public static String a() {
        return ("TDJabFpXUnpMM0J2YzNSekwyUmxabUYxYkhRL1lXeDBQV3B6YjI0PQ==SDdByADudCh2E3eLgrk66m45KdtQAb").replaceAll("SDdByADudCh2E3eLgrk66m45KdtQAb", "");
    }
}
