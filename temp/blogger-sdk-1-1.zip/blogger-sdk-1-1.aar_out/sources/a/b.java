package a;

import dreamspace.blogger.sdk.connection.API;
import java.util.concurrent.TimeUnit;
import okhttp3.Cache;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
/* loaded from: input.aar:classes.jar:a/b.class */
public final class b {
    public static API a(String str) {
        new HttpLoggingInterceptor();
        OkHttpClient.Builder builder = new OkHttpClient.Builder();
        TimeUnit timeUnit = TimeUnit.SECONDS;
        builder.connectTimeout(5L, timeUnit);
        builder.writeTimeout(10L, timeUnit);
        builder.readTimeout(30L, timeUnit);
        builder.pingInterval(1L, timeUnit);
        builder.retryOnConnectionFailure(true);
        builder.cache((Cache) null);
        return (API) new Retrofit.Builder().baseUrl("https://" + str).addConverterFactory(GsonConverterFactory.create()).client(builder.build()).build().create(API.class);
    }
}
