package dreamspace.blogger.sdk;

import b.b;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import dreamspace.blogger.sdk.listener.RequestListener;
import dreamspace.blogger.sdk.model.ParamList;
import dreamspace.blogger.sdk.model.RespPosts;
import java.util.List;
import java.util.Map;
import retrofit2.Call;
/* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/BloggerAPI.class */
public class BloggerAPI {
    private static Map<String, String> accessKey;
    private static b.a crypto;
    private static String invalid_key = "Invalid access key, please generate from www.dream-space.web.id/blogger/access-key";
    private static String invalid_access = "This access key only allow for URL : ";

    /* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/BloggerAPI$a.class */
    public class a extends TypeToken<Map<String, String>> {
    }

    public BloggerAPI(String str) {
        b.a a2 = b.a.a(str);
        crypto = a2;
        if (a2.b()) {
            return;
        }
        accessKey = (Map) new Gson().fromJson(crypto.a(), new a().getType());
    }

    public Call getCategories(String str, RequestListener<List<String>> requestListener) {
        if (crypto.b()) {
            requestListener.onFailed(invalid_key);
            return null;
        } else if (accessKey.get("blogger_url") == null) {
            requestListener.onFailed(invalid_key);
            return null;
        } else if (!accessKey.get("blogger_url").equals(str)) {
            requestListener.onFailed(invalid_access + accessKey.get("blogger_url"));
            return null;
        } else {
            return b.a(str, requestListener);
        }
    }

    public Call getPosts(ParamList paramList, RequestListener<RespPosts> requestListener) {
        if (crypto.b()) {
            requestListener.onFailed(invalid_key);
            return null;
        } else if (accessKey.get("blogger_url") == null) {
            requestListener.onFailed(invalid_key);
            return null;
        } else if (!accessKey.get("blogger_url").equals(paramList.url)) {
            requestListener.onFailed(invalid_access + accessKey.get("blogger_url"));
            return null;
        } else {
            return b.b(paramList, requestListener);
        }
    }

    public Call getPages(ParamList paramList, RequestListener<RespPosts> requestListener) {
        if (crypto.b()) {
            requestListener.onFailed(invalid_key);
            return null;
        } else if (accessKey.get("blogger_url") == null) {
            requestListener.onFailed(invalid_key);
            return null;
        } else if (!accessKey.get("blogger_url").equals(paramList.url)) {
            requestListener.onFailed(invalid_access + accessKey.get("blogger_url"));
            return null;
        } else {
            return b.a(paramList, requestListener);
        }
    }
}
