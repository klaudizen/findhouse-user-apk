package dreamspace.blogger.sdk.listener;
/* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/listener/RequestListener.class */
public class RequestListener<T> {
    public void onFinish() {
    }

    public void onSuccess(T t) {
    }

    public void onFailed(String str) {
    }
}
