package dreamspace.blogger.sdk.connection.response;

import java.io.Serializable;
import java.util.List;
/* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/connection/response/RespAtom.class */
public class RespAtom implements Serializable {
    public Feed feed;

    /* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/connection/response/RespAtom$Category.class */
    public class Category {
        public String term;

        public Category() {
        }
    }

    /* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/connection/response/RespAtom$Feed.class */
    public class Feed {
        public List<Category> category;

        public Feed() {
        }
    }
}
