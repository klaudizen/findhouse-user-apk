package dreamspace.blogger.sdk.connection;

import dreamspace.blogger.sdk.connection.response.RespAtom;
import dreamspace.blogger.sdk.connection.response.RespObject;
import java.util.Map;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.QueryMap;
import retrofit2.http.Url;
/* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/connection/API.class */
public interface API {
    public static final String CACHE = "Cache-Control: max-age=0";
    public static final String AGENT = "User-Agent: Android";

    @Headers({CACHE, AGENT})
    @GET
    Call<RespObject> getPosts(@Url String str, @QueryMap Map<String, String> map);

    @Headers({CACHE, AGENT})
    @GET
    Call<RespObject> getPages(@Url String str, @QueryMap Map<String, String> map);

    @Headers({CACHE, AGENT})
    @GET
    Call<RespAtom> getAtom(@Url String str);
}
