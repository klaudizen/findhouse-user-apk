package dreamspace.blogger.sdk.connection.response;

import com.google.gson.JsonElement;
import java.io.Serializable;
/* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/connection/response/RespObject.class */
public class RespObject implements Serializable {
    public JsonElement feed;
}
