package dreamspace.blogger.sdk.model;

import android.text.TextUtils;
import java.util.HashMap;
import java.util.Map;
/* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/model/ParamList.class */
public class ParamList {
    public String url;
    public String page = "1";
    public String count = "10";
    public String category;
    public String keyword;

    public Map<String, String> getParams() {
        HashMap hashMap = new HashMap();
        if (!TextUtils.isEmpty(this.page)) {
            hashMap.put("start-index", String.valueOf(((Integer.parseInt(this.page) - 1) * Integer.parseInt(this.count)) + 1));
        }
        if (!TextUtils.isEmpty(this.count)) {
            hashMap.put("max-results", this.count);
        }
        if (!TextUtils.isEmpty(this.category)) {
            hashMap.put("category", this.category);
        }
        if (!TextUtils.isEmpty(this.keyword)) {
            hashMap.put("q", this.keyword);
        }
        return hashMap;
    }
}
