package dreamspace.blogger.sdk.model;

import java.io.Serializable;
import java.util.List;
/* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/model/RespPosts.class */
public class RespPosts implements Serializable {
    public int status = -1;
    public String messages = "";
    public int count = -1;
    public int count_total = -1;
    public int page = -1;
    public List<Listing> list;
}
