package dreamspace.blogger.sdk.model;

import java.io.Serializable;
import java.util.List;
/* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/model/Listing.class */
public class Listing implements Serializable {
    public String id;
    public String type;
    public String title;
    public String published;
    public String updated;
    public String content;
    public String link;
    public List<String> category;
    public Author author;
}
