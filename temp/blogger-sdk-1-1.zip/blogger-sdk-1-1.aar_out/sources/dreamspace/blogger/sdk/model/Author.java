package dreamspace.blogger.sdk.model;

import java.io.Serializable;
/* loaded from: input.aar:classes.jar:dreamspace/blogger/sdk/model/Author.class */
public class Author implements Serializable {
    public String name;
    public String uri;
    public String email;
    public String image;
}
